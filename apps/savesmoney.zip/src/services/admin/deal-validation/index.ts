import Cookies from 'js-cookie';

export const deleteValidation = async (id: string) => {
    try {
        const res = await fetch(`/api/admin/deal-validation/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${Cookies.get('token')}`,
            },
        });

        const data = await res.json();
        return data;
    } catch (error) {
        console.log('Error in deleting Validation (service) =>', error);
    }
};

export const updateValidationStatus = async (dealId: string, invalid: boolean) => {
    try {
        const res = await fetch(`/api/admin/deal/${dealId}/validation`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${Cookies.get('token')}`,
            },
            body: JSON.stringify({ invalid }),
        });

        const data = await res.json();
        return data;
    } catch (error) {
        console.log('Error in updating deal validation status (service) =>', error);
    }
};
