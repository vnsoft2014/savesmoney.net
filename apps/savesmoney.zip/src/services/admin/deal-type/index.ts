import { ApiResponse, DealType } from '@/types';
import { fetcher, fetcherWithAuth } from '@/utils/utils';

export const addDealType = async (formData: any) => {
    const data = await fetcherWithAuth('/api/admin/deal-type', {
        method: 'POST',
        body: formData,
    });

    return data;
};

export const deleteDealType = async (id: string) => {
    const data = await fetcherWithAuth(`${process.env.NEXT_PUBLIC_API_BASE_URL}/admin/deal-type/${id}`, {
        method: 'DELETE',
    });

    return data;
};

export const updateDealType = async (id: string, formData: any) => {
    const data = await fetcherWithAuth(`${process.env.NEXT_PUBLIC_API_BASE_URL}/admin/deal-type/${id}`, {
        method: 'PATCH',
        body: formData,
    });

    return data;
};

export const getDealTypeById = async (id: string) => {
    const data = await fetcher(`${process.env.NEXT_PUBLIC_API_BASE_URL}/common/deal-type/${id}`, {
        method: 'GET',
    });

    return data;
};

export const getDealTypes = async (): Promise<DealType[]> => {
    try {
        const res: ApiResponse<DealType[]> = await fetcher(
            `${process.env.NEXT_PUBLIC_API_BASE_URL}/common/deal-type/all`,
            {
                method: 'GET',
                cache: 'no-store',
            },
        );
        if (!res || !res.success) {
            return [];
        }

        return res.data;
    } catch (error) {
        return [];
    }
};
