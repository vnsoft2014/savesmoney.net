import Cookies from "js-cookie";

export const updateSettings = async (data: FormData) => {
  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${Cookies.get("token")}`,
      },
      body: data,
    });

    const result = await res.json();
    return result;
  } catch (error) {
    console.error(error);
    return { success: false, message: "Something went wrong" };
  }
};

export const getSettings = async () => {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/settings`, {
            method: 'GET',
            cache: 'no-store',
        });
        const data = await res.json();

        return data;
    } catch(error) {}
}