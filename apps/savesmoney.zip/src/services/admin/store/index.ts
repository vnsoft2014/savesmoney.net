import { Store } from '@/types';
import { fetcher, fetcherWithAuth } from '@/utils/utils';

export const addStore = async (formData: any) => {
    try {
        const data = await fetcherWithAuth(`${process.env.NEXT_PUBLIC_API_BASE_URL}/admin/store`, {
            method: 'POST',
            body: formData,
        });

        return data;
    } catch (error) {
        console.error('Add store error:', error);
    }
};

export const deleteStore = async (id: string) => {
    const data = await fetcherWithAuth(`${process.env.NEXT_PUBLIC_API_BASE_URL}/admin/store/${id}`, {
        method: 'DELETE',
    });

    return data;
};

export const updateStore = async (id: string, formData: any) => {
    const data = await fetcherWithAuth(`${process.env.NEXT_PUBLIC_API_BASE_URL}/admin/store/${id}`, {
        method: 'PATCH',
        body: formData,
    });

    return data;
};

export const getStoreById = async (id: string) => {
    const data = await fetcher(`${process.env.NEXT_PUBLIC_API_BASE_URL}/common/store/${id}`, {
        method: 'GET',
    });

    return data;
};

export const getStores = async (): Promise<Store[]> => {
    try {
        const res = await fetcher(`${process.env.NEXT_PUBLIC_API_BASE_URL}/common/store/all`, {
            method: 'GET',
            cache: 'no-store',
        });

        if (!res || !res.success) {
            console.error('API Error:', res?.message);
            return [];
        }

        return res.data;
    } catch (error) {
        return [];
    }
};
