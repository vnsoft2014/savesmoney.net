'use client';

import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { persistReducer, persistStore } from 'redux-persist';
import storage from './storage';

import { AdminNavReducer } from '@/utils/AdminNavSlice';
import { UserReducer } from '@/utils/UserDataSlice';
import { FrontendNavReducer } from '@/utils/FrontendNavSlice';

const rootReducer = combineReducers({
    User: UserReducer,
    AdminNav: AdminNavReducer,
    FrontendNav: FrontendNavReducer,
});

export type RootState = ReturnType<typeof rootReducer>;

const persistConfig = {
    key: 'root',
    storage,
    whitelist: ['User', 'AdminNav'],
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: false,
        }),
});

export const persistor = persistStore(store);

export type AppDispatch = typeof store.dispatch;
