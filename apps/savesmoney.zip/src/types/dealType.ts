export type DealType = {
    _id: string;
    thumbnail: string;
    name: string;
    slug: string;
};
