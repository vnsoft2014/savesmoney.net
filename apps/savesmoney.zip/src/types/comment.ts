export type CommentData = {
    _id: string;
    username: string;
    content: string;
    likes: number;
    likedBy: string[];
    createdAt: string;
    parentId: string;
    isApproved: boolean;
    deal: {
        _id: string,
        shortDescription: string,
    },
    user: {
        _id: string,
        name: string;
        avatar: string;
    } | null;

    repliesCount: number;

    replies?: CommentData[];
    repliesPage?: number;
    repliesHasMore?: boolean;
    loadingReplies?: boolean;
};