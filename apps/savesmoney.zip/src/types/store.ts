export type Store = {
    _id: string;
    thumbnail: string;
    name: string;
    slug: string;
};
