export {};

declare global {
  interface Window {
    adsbygoogle: unknown[];
  }
}
