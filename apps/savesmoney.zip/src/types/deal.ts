import { PaginatedResponse } from './common';
import { DealType } from './dealType';
import { Store } from './store';
import { User } from './user';

// export type Deal = {
//     id: number;
//     picture: string | null;
//     dealType: string[];
//     store: string;
//     expireAt: string | null;
//     shortDescription: string;
//     originalPrice: number;
//     discountPrice: number;
//     percentageOff: string;
//     purchaseLink: string;
//     description: string;
//     tags: string;
//     hotTrend: boolean;
//     holidayDeals: boolean;
//     seasonalDeals: boolean;
//     coupon: boolean;
//     clearance: boolean;
//     disableExpireAt: boolean;
// };

export type Deal = {
    _id: string;

    image: string;
    dealType: DealType[];

    store: Store;
    expireAt: string | null;

    shortDescription: string;
    slug: string;
    originalPrice: number;
    discountPrice: number;
    percentageOff: string;

    purchaseLink: string;
    description: string;

    hotTrend: boolean;
    holidayDeals: boolean;
    seasonalDeals: boolean;

    coupon: boolean;
    clearance: boolean;
    disableExpireAt: boolean;

    author: User;

    createdAt: string;
    updatedAt: string;
};

export type GetActiveDealsParams = {
    dealType?: string;
    dealStore?: string;
    page?: number;
    limit?: number;
    search?: string;
    sortField?: 'createdAt' | 'expiredAt' | 'originalPrice' | 'discountPrice';
    sortOrder?: 'asc' | 'desc';
    hotTrend?: boolean;
    holidayDeals?: boolean;
    seasonalDeals?: boolean;
    expireAt?: 'null';
};

export type DealListResponse = PaginatedResponse<Deal>;
