'use client';

import DealsFilters from '@/components/deal/components/DealsFilters';
import RecommendedDeals from '@/components/home/components/RecommendedDeals';
import Sidebar from '@/components/layout/Sidebar';
import { getActiveDeals } from '@/services/comment/deal';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { DealCard } from '../common';
import NoDeals from '../deals/NoDeals';
import Loading from '../loading';
import HomeSchema from '../seo/HomeSchema';
import GoogleAds from '../widgets/Ads';

interface Props {
    recommenedDealsData: any;
    expiringDealsData: any;
    initialDealsData: any;
    dealTypesData: any;
    storesData: any;
    initialDealType: string;
    initialStore: string;
}

const DesktopPage = ({
    recommenedDealsData,
    expiringDealsData,
    initialDealsData,
    dealTypesData,
    storesData,
    initialDealType,
    initialStore,
}: Props) => {
    const [dealsData, setDealsData] = useState<any>(initialDealsData || null);

    const [loading, setLoading] = useState(!initialDealsData);

    const searchParams = useSearchParams();

    const finalDealType = initialDealType || searchParams.get('dealType') || '';
    const finalStore = initialStore || searchParams.get('store') || '';

    useEffect(() => {
        let mounted = true;

        const fetchDeals = async () => {
            setLoading(true);
            const res = await getActiveDeals(finalDealType, finalStore, 1, {
                limit: 30,
            });

            if (mounted) setDealsData(res);
            setLoading(false);
        };

        fetchDeals();

        return () => {
            mounted = false;
        };
    }, [finalDealType, finalStore]);

    return (
        <>
            <HomeSchema />
            <div className="container min-h-screen mx-auto px-3 pb-6">
                <div className="grid grid-cols-1 lg:grid-cols-5">
                    <main className="lg:col-span-4 px-4">
                        <RecommendedDeals initialDealsData={recommenedDealsData} />

                        <GoogleAds slot="2176866845" />

                        <div className="mt-2 lg:mt-8">
                            <div className="flex flex-col md:flex-row justify-center md:justify-between items-center text-sm breadcrumbs mb-4">
                                <h3 className="text-lg lg:text-xl font-bold">Expiring Soon</h3>

                                <Link
                                    href="/expiring-soon"
                                    className="inline-flex items-center gap-1 text-sm font-medium text-orange-500 hover:gap-2 transition-all"
                                >
                                    See all
                                    <ArrowRight className="w-4 h-4" />
                                </Link>
                            </div>
                            <div className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
                                {expiringDealsData.data.map((deal: any) => {
                                    return <DealCard key={`expiring-soon-${deal._id}`} deal={deal} />;
                                })}
                            </div>
                        </div>

                        <GoogleAds slot="2176866845" />

                        <div className="mt-2 lg:mt-8">
                            <div className="flex flex-col md:flex-row justify-center md:justify-between items-center text-sm breadcrumbs mb-4">
                                <h3 className="text-lg lg:text-xl font-bold">All The Deals</h3>

                                <DealsFilters
                                    showTypeFilter={true}
                                    dealTypes={dealTypesData.data}
                                    stores={storesData.data}
                                />
                            </div>

                            {loading ? (
                                <Loading />
                            ) : !dealsData?.success || dealsData?.data.length === 0 ? (
                                <NoDeals />
                            ) : (
                                <div className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
                                    {dealsData.data.map((deal: any) => {
                                        return <DealCard key={deal._id} deal={deal} />;
                                    })}
                                </div>
                            )}
                        </div>
                    </main>

                    <Sidebar />
                </div>
            </div>
        </>
    );
};

export default DesktopPage;
