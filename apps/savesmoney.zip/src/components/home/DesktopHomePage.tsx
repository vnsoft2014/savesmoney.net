import DealsFilters from '@/components/deal/components/DealsFilters';
import Sidebar from '@/components/layout/Sidebar';
import { DealListResponse, DealType, Store } from '@/types';
import HomeSchema from '../seo/HomeSchema';
import GoogleAds from '../widgets/Ads';
import { DealsGrid, DealTypeGrid } from './components';

interface Props {
    dealListResponse: DealListResponse;
    dealTypes: DealType[];
    stores: Store[];
}

const DesktopHomePage = async ({ dealListResponse, dealTypes, stores }: Props) => {
    return (
        <>
            <HomeSchema />
            <div className="container min-h-screen mx-auto px-3 pb-6">
                <div className="grid grid-cols-1 xl:grid-cols-5 lg:grid-cols-7">
                    <main className="xl:col-span-4 lg:col-span-5 px-3 py-10 space-y-8">
                        <DealTypeGrid dealTypes={dealTypes} />

                        <GoogleAds slot="2176866845" />

                        <div>
                            <div className="flex flex-col md:flex-row justify-center md:justify-between items-center text-sm breadcrumbs mb-4">
                                <h3 className="text-lg lg:text-xl font-bold">All The Deals</h3>

                                <DealsFilters showTypeFilter={true} dealTypes={dealTypes} stores={stores} />
                            </div>

                            <DealsGrid initDealListResponse={dealListResponse} />
                        </div>
                    </main>

                    <Sidebar />
                </div>
            </div>
        </>
    );
};

export default DesktopHomePage;
