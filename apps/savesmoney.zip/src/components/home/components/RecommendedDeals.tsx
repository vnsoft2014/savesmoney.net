'use client';

import { DealData } from '@/types';
import { useEffect, useRef, useState } from 'react';
import { Navigation } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import { DealCard } from '@/components/common';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import 'swiper/css';
import 'swiper/css/navigation';

type Props = {
    initialDealsData: any;
};

export default function RecommendedDeals({ initialDealsData }: Props) {
    const [deals, setDeals] = useState<DealData[]>([]);

    const [isBeginning, setIsBeginning] = useState(true);
    const [isEnd, setIsEnd] = useState(false);

    const prevRef = useRef<HTMLButtonElement>(null);
    const nextRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        if (initialDealsData.success) setDeals(initialDealsData.data);
    }, [initialDealsData]);

    return (
        <div className="py-4">
            <div className="flex justify-between mb-4">
                <h3 className="text-lg lg:text-xl font-bold">Just For You</h3>

                <div className="flex items-center gap-3">
                    <button
                        ref={prevRef}
                        disabled={isBeginning}
                        className={`
              flex justify-center items-center w-9 h-9 rounded-full border transition
              ${isBeginning ? 'border-gray-300 text-gray-300 cursor-not-allowed' : 'border-gray-400 hover:bg-gray-100'}
            `}
                    >
                        <ChevronLeft className="w-4 h-4" />
                    </button>

                    <button
                        ref={nextRef}
                        disabled={isEnd}
                        className={`
              flex justify-center items-center w-9 h-9 rounded-full border transition
              ${isEnd ? 'border-gray-300 text-gray-300 cursor-not-allowed' : 'border-gray-400 hover:bg-gray-100'}
            `}
                    >
                        <ChevronRight className="w-4 h-4" />
                    </button>
                </div>
            </div>

            <Swiper
                modules={[Navigation]}
                spaceBetween={16}
                slidesPerView={1}
                navigation={{
                    prevEl: prevRef.current,
                    nextEl: nextRef.current,
                }}
                onBeforeInit={(swiper) => {
                    // @ts-ignore
                    swiper.params.navigation.prevEl = prevRef.current;
                    // @ts-ignore
                    swiper.params.navigation.nextEl = nextRef.current;
                }}
                onSlideChange={(swiper) => {
                    setIsBeginning(swiper.isBeginning);
                    setIsEnd(swiper.isEnd);
                }}
                breakpoints={{
                    640: { slidesPerView: 1 },
                    768: { slidesPerView: 3 },
                    1280: { slidesPerView: 5 },
                }}
            >
                {deals.map((deal) => (
                    <SwiperSlide key={deal._id}>
                        <DealCard deal={deal} />
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
    );
}
