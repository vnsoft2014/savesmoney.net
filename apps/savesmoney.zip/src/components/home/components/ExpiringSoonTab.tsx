'use client';

import { DealData } from '@/types';
import React, { useEffect, useState } from 'react';

import { DealCard } from '@/components/common';
import GoogleAds from '@/components/widgets/Ads';
import { ArrowRight } from 'lucide-react';
import Link from 'next/link';

type Props = {
    expiringDealsData: any;
};

export default function ExpiringSoonTab({ expiringDealsData }: Props) {
    const [deals, setDeals] = useState<DealData[]>([]);

    useEffect(() => {
        if (expiringDealsData.success) setDeals(expiringDealsData.data);
    }, [expiringDealsData]);

    return (
        <div className="py-4">
            <div className="grid gap-3 grid-cols-1 md:grid-cols-3 xl:grid-cols-5">
                {deals.map((deal, index) => {
                    return (
                        <React.Fragment key={`expiring-soon-${deal._id}`}>
                            <DealCard deal={deal} />

                            {(index + 1) % 10 === 0 && <GoogleAds slot="2176866845" />}
                        </React.Fragment>
                    );
                })}
            </div>

            <div className="mt-3 text-center">
                <Link
                    href="/expiring-soon"
                    className="inline-flex items-center gap-1 text-sm font-medium text-orange-500 hover:gap-2 transition-all"
                >
                    See all
                    <ArrowRight className="w-4 h-4" />
                </Link>
            </div>
        </div>
    );
}
