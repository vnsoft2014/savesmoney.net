export { default as DealCard } from './DealCard';
export { default as DealPrice } from './DealPrice';
