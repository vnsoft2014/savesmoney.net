import { getDealTypes } from '@/services/admin/deal-type';
import { getSettings } from '@/services/admin/settings';
import { headerData } from '@/shared/data/global.data';
import { MainNavClient } from './components';

const MainNav = async () => {
    const { links } = headerData;

    const [dealTypes, settingsRes] = await Promise.all([getDealTypes(), getSettings()]);

    const holidayDealsLabel = settingsRes?.holidayDealsLabel || 'Holiday Deals';
    const seasonalDealsLabel = settingsRes?.seasonalDealsLabel || 'Seasonal Deals';

    const dealTypeLinks = dealTypes.map((type: any) => ({
        label: type.name,
        href: `/deals/${type.slug}-${type._id}`,
    }));

    const updatedLinks = links?.map((item) => {
        if (item.href === '/deals') {
            return {
                ...item,
                links: dealTypeLinks,
            };
        } else if (item.href === '/holiday-deals') {
            return {
                ...item,
                label: holidayDealsLabel,
            };
        } else if (item.href === '/seasonal-deals') {
            return {
                ...item,
                label: seasonalDealsLabel,
            };
        }

        return item;
    });

    return <MainNavClient links={updatedLinks} settings={settingsRes} />;
};

export default MainNav;
