'use client';
/* eslint-disable @next/next/no-img-element */
import { useAuth } from '@/hooks/useAuth';
import { useIdleLogout } from '@/hooks/useIdleLogout';
import { announcementData } from '@/shared/data/global.data';
import Link from 'next/link';
import { memo } from 'react';
import { MobileMenu } from '../layout';
import { Button } from '../ui/button';
import { AutoLogoutWarning } from '../widgets/AutoLogoutWarning';
import { Logo, SearchBox, TopNavClient, UserDropDown } from './components';

const Announcement = () => {
    const { title, callToAction } = announcementData;

    const { user, isSignin, isAdmin, login, logout } = useAuth();

    const { showPopup, stayLoggedIn, logoutNow } = useIdleLogout(logout, isAdmin);

    return (
        <>
            {isAdmin && showPopup && <AutoLogoutWarning onStayActive={stayLoggedIn} onLogout={logoutNow} />}
            <div className="hidden md:block w-full bg-blue-950 px-3 py-2 text-gray-200 text-[11px] italic text-center">
                When you buy through links on Savesmoney.net, we may earn a commission.
            </div>
            <div className="relative w-full bg-blue-900 border-b border-blue-800">
                <div className="xl:container mx-auto px-3">
                    <div className="flex justify-between items-center gap-2 md:gap-4 py-3">
                        <div className="shrink-0">
                            <Link href="/">
                                <Logo />
                            </Link>
                            <div className="hidden lg:block overflow-hidden text-ellipsis whitespace-nowrap text-sm text-gray-200 mt-1">
                                <span className="bg-blue-800 py-0.5 px-1 font-semibold text-xs md:text-sm">
                                    {title}
                                </span>{' '}
                                {callToAction && callToAction.text && callToAction.href && (
                                    <span className="cursor-pointer text-gray-100 text-xs md:text-sm hover:text-white transition-colors">
                                        {callToAction.icon && (
                                            <callToAction.icon className="inline mr-1 -ml-1.5 h-4 w-4" />
                                        )}
                                        {callToAction.text}
                                    </span>
                                )}
                            </div>
                        </div>

                        <div className="flex-1 lg:max-w-2xl">
                            <SearchBox />
                        </div>

                        <div className="hidden xl:flex items-center gap-6">
                            <TopNavClient />

                            {isSignin && user ? (
                                <UserDropDown user={user} handleSignOut={logout} />
                            ) : (
                                <Button
                                    onClick={login}
                                    className="px-4 lg:px-5 py-2 text-sm font-semibold bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                                >
                                    Sign In
                                </Button>
                            )}
                        </div>

                        <MobileMenu />
                    </div>
                </div>
            </div>
        </>
    );
};

export default memo(Announcement);
