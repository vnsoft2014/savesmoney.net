const Logo = () => (
    <span className="self-center whitespace-nowrap text-base md:text-xl font-bold text-white">SavesMoney</span>
);

export default Logo;
