export { default as Pagination } from './Pagination';
export { default as PopularDeals } from './PopularDealsItem';
