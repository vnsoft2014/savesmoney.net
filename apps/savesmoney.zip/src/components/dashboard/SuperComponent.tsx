'use client';

import { RootState } from '@/store/store';
import { useSelector } from 'react-redux';
import CommentDataTable from './CommentDataTable';
import DealDataTable from './DealDataTable';
import DealTypeDataTable from './DealTypeDataTable';
import Settings from './Settings';
import StoreDataTable from './StoreDataTable';
import SubscriberDataTable from './SubscriberDataTable';
import UserDataTable from './UserDataTable';
import ValidationDataTable from './ValidationDataTable';

export default function SuperComponent() {
    const navActive = useSelector((state: RootState) => state.AdminNav.ActiveNav);

    switch (navActive) {
        case 'activeDealTypes':
            return <DealTypeDataTable />;
        case 'activeDealVerification':
            return <ValidationDataTable />;
        case 'activeStores':
            return <StoreDataTable />;
        case 'activeComments':
            return <CommentDataTable />;
        case 'activeSubscribers':
            return <SubscriberDataTable />;
        case 'activeUsers':
            return <UserDataTable />;
        case 'activeSettings':
            return <Settings />;
        case 'activeDeals':
        default:
            return <DealDataTable />;
    }
}

export const dynamic = 'force-dynamic';
