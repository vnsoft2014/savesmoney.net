'use client';

import React, { useRef } from 'react';
import { Upload, Clipboard } from 'lucide-react';

interface PictureUploadCellProps {
    deal: any;
    uploading: boolean;
    focusedDealId: number | null;
    setFocusedDealId: (id: number | null) => void;
    onUpload: (dealId: number, e: React.ChangeEvent<HTMLInputElement> | any) => void;
    error?: string;
}

const PictureUploadCell: React.FC<PictureUploadCellProps> = ({
    deal,
    uploading,
    focusedDealId,
    setFocusedDealId,
    onUpload,
    error,
}) => {
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const containerRef = useRef(null);

    const handleContainerClick = () => {
        console.log('click');

        if (!uploading) {
            fileInputRef.current?.click();
        }
    };

    const handleFocus = () => {
        console.log('focus');

        setFocusedDealId(deal.id);
    };

    const handleBlur = () => {
        console.log('blur');

        setTimeout(() => {
            if (focusedDealId === deal.id) {
                setFocusedDealId(null);
            }
        }, 100);
    };

    return (
        <td className="px-4 py-3">
            <div className="flex flex-col items-center gap-2">
                {uploading && <div className="text-xs text-blue-600 font-medium animate-pulse">Uploading...</div>}

                {deal.picture && (
                    <div className="relative group">
                        <img
                            src={deal.picture}
                            alt="Deal"
                            className="w-20 h-20 object-cover rounded-lg border-2 border-gray-300 shadow-sm"
                        />
                        <button
                            onClick={handleContainerClick}
                            className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg"
                        >
                            <Upload size={20} className="text-white" />
                        </button>
                    </div>
                )}

                {/* Paste Area */}
                <div
                    ref={containerRef}
                    tabIndex={0}
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    onClick={handleContainerClick}
                    className={`w-full border-2 border-dashed rounded-lg p-3 text-center cursor-pointer transition-all outline-none
                        ${
                            uploading
                                ? 'border-gray-300 bg-gray-50 cursor-not-allowed opacity-50'
                                : focusedDealId === deal.id
                                  ? 'border-blue-500 bg-blue-100 ring-2 ring-blue-300'
                                  : 'border-blue-300 bg-blue-50 hover:bg-blue-100 hover:border-blue-400'
                        }
                    `}
                >
                    <div className="flex flex-col items-center gap-1">
                        <Clipboard size={20} className="text-blue-600" />
                        <span className="text-xs text-gray-600 font-medium">
                            {focusedDealId === deal.id ? 'Press Ctrl+V' : 'Click or Focus'}
                        </span>
                    </div>
                </div>

                <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/webp,image/gif"
                    onChange={(e) => onUpload(deal.id, e)}
                    disabled={uploading}
                    className="hidden"
                />

                {error && <span className="text-xs text-red-500 font-medium">{error}</span>}
            </div>
        </td>
    );
};

export default PictureUploadCell;
