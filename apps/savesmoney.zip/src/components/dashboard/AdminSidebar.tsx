'use client';

import { useAuth } from '@/hooks/useAuth';
import { setNavActive } from '@/utils/AdminNavSlice';
import { Bell, Home, LayoutDashboard, MessageCircle, Package, PlusCircle, Settings, Store, Tags } from 'lucide-react';
import Link from 'next/link';
import { useDispatch } from 'react-redux';

export default function AdminSidebar() {
    const dispatch = useDispatch();

    const { user } = useAuth();

    return (
        <div className="w-60 hidden dark:text-black md:block bg-white h-full">
            <div className="w-full flex items-center text-center py-2 px-2 h-20 gap-3">
                <Link href="/" className="flex items-center justify-center">
                    <Home size={30} className="mx-2 text-blue-500" />
                </Link>

                <h1 className="flex text-xl! font-semibold items-center justify-center">
                    <LayoutDashboard className="mx-2" />
                    Dashboard
                </h1>
            </div>

            <div className="w-full">
                <ul className="flex px-4 flex-col items-start justify-center">
                    <li onClick={() => dispatch(setNavActive('activeDeals'))} className="py-3 px-1 mb-3">
                        <button className="flex items-center justify-center">
                            <Package size={20} className="mx-2 text-blue-500" />
                            Deals
                        </button>
                    </li>

                    <li className="py-3 px-1 mb-3">
                        <Link href="/dashboard/deal/add" className="flex items-center justify-center">
                            <PlusCircle size={20} className="mx-2 text-blue-500" />
                            Add Deals
                        </Link>
                    </li>

                    <li onClick={() => dispatch(setNavActive('activeDealVerification'))} className="py-3 px-1 mb-3">
                        <button className="flex items-center justify-center">
                            <Package size={20} className="mx-2 text-blue-500" />
                            Deal Validations
                        </button>
                    </li>

                    <li onClick={() => dispatch(setNavActive('activeDealTypes'))} className="py-3 px-1 mb-3">
                        <button className="flex items-center justify-center">
                            <Tags size={20} className="mx-2 text-blue-500" />
                            Deal Types
                        </button>
                    </li>

                    <li onClick={() => dispatch(setNavActive('activeStores'))} className="py-3 px-1 mb-3">
                        <button className="flex items-center justify-center">
                            <Store size={20} className="mx-2 text-blue-500" />
                            Stores
                        </button>
                    </li>

                    <li onClick={() => dispatch(setNavActive('activeComments'))} className="py-3 px-1 mb-3">
                        <button className="flex items-center justify-center">
                            <MessageCircle size={20} className="mx-2 text-blue-500" />
                            Comments
                        </button>
                    </li>

                    {user?.role === 'admin' && (
                        <>
                            <li onClick={() => dispatch(setNavActive('activeSubscribers'))} className="py-3 px-1 mb-3">
                                <button className="flex items-center justify-center">
                                    <Bell size={20} className="mx-2 text-blue-500" />
                                    Subscribers
                                </button>
                            </li>
                            <li onClick={() => dispatch(setNavActive('activeUsers'))} className="py-3 px-1 mb-3">
                                <button className="flex items-center justify-center">
                                    <Package size={20} className="mx-2 text-blue-500" />
                                    Users
                                </button>
                            </li>

                            <li onClick={() => dispatch(setNavActive('activeSettings'))} className="py-3 px-1 mb-3">
                                <button className="flex items-center justify-center">
                                    <Settings size={20} className="mx-2 text-blue-500" />
                                    Settings
                                </button>
                            </li>
                        </>
                    )}
                </ul>
            </div>
        </div>
    );
}
