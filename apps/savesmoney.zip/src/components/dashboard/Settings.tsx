'use client';

import { getSettings, updateSettings } from '@/services/admin/settings';
import { SettingsForm } from '@/types/settings';
import { settingsDefault } from '@/utils/settings';
import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import Loading from '../loading';

export default function Settings() {
    const [formData, setFormData] = useState<SettingsForm>(settingsDefault);
    const [logoFile, setLogoFile] = useState<File | null>(null);
    const [faviconFile, setFaviconFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);

    const [errors, setErrors] = useState<Partial<SettingsForm>>({});
    const [socialErrors, setSocialErrors] = useState<Partial<SettingsForm['socialLinks']>>({});

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                setLoading(true);
                const data = await getSettings();
                if (data) {
                    setFormData({
                        websiteTitle: data.websiteTitle || '',
                        websiteDescription: data.websiteDescription || '',
                        logo: data.logo || '',
                        favicon: data.favicon || '',
                        holidayDealsLabel: data.holidayDealsLabel || '',
                        seasonalDealsLabel: data.seasonalDealsLabel || '',
                        adminEmail: data.adminEmail || '',
                        socialLinks: {
                            facebookPage: data.socialLinks?.facebookPage || '',
                            facebookGroup: data.socialLinks?.facebookGroup || '',
                            x: data.socialLinks?.x || '',
                            instagram: data.socialLinks?.instagram || '',
                            linkedin: data.socialLinks?.linkedin || '',
                        },
                    });
                }
            } catch (err: any) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchSettings();
    }, []);

    const handleChange = <K extends keyof SettingsForm>(field: K, value: SettingsForm[K]) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
        setErrors((prev) => ({ ...prev, [field]: undefined }));
    };

    const handleSocialChange = <K extends keyof SettingsForm['socialLinks']>(field: K, value: string) => {
        let url = value.trim();
        if (url && !/^https?:\/\//i.test(url)) url = 'https://' + url;

        setFormData((prev) => ({
            ...prev,
            socialLinks: { ...prev.socialLinks, [field]: url },
        }));
        setSocialErrors((prev) => ({ ...prev, [field]: undefined }));
    };

    const validate = () => {
        const newErrors: Partial<SettingsForm> = {};
        const newSocialErrors: Partial<SettingsForm['socialLinks']> = {};

        if (!formData.websiteTitle.trim()) newErrors.websiteTitle = 'Website Title is required';
        if (!formData.websiteDescription.trim()) newErrors.websiteDescription = 'Website Description is required';
        if (!formData.adminEmail.trim()) newErrors.adminEmail = 'Admin Email is required';
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.adminEmail)) newErrors.adminEmail = 'Invalid email format';

        setErrors(newErrors);
        setSocialErrors(newSocialErrors);

        return Object.keys(newErrors).length === 0 && Object.keys(newSocialErrors).length === 0;
    };

    const handleSave = async () => {
        if (!validate()) return;

        try {
            setSaving(true);

            const formDataToSend = new FormData();

            formDataToSend.append('websiteTitle', formData.websiteTitle);
            formDataToSend.append('websiteDescription', formData.websiteDescription);
            formDataToSend.append('holidayDealsLabel', formData.holidayDealsLabel);
            formDataToSend.append('seasonalDealsLabel', formData.seasonalDealsLabel);
            formDataToSend.append('adminEmail', formData.adminEmail);

            Object.entries(formData.socialLinks).forEach(([key, value]) => {
                formDataToSend.append(`socialLinks[${key}]`, value || '');
            });

            if (logoFile) formDataToSend.append('logo', logoFile);
            if (faviconFile) formDataToSend.append('favicon', faviconFile);

            const result = await updateSettings(formDataToSend);
            if (!result.success) {
                throw new Error(result.message || 'Failed to save settings');
            }
            toast.success('Settings updated successfully!');
        } catch (err: any) {
            toast.error(err.message || 'Something went wrong');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return <Loading />;

    return (
        <div className="w-full h-full p-6 bg-white">
            <div className="max-w-2xl mx-auto space-y-8">
                {/* Website Info */}
                <div>
                    <h2 className="text-xl font-semibold mb-6">Website Info</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Website Title</label>
                            <input
                                type="text"
                                value={formData.websiteTitle}
                                onChange={(e) => handleChange('websiteTitle', e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            {errors.websiteTitle && <p className="text-red-500 text-sm mt-1">{errors.websiteTitle}</p>}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Website Description</label>
                            <textarea
                                value={formData.websiteDescription}
                                onChange={(e) => handleChange('websiteDescription', e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows={3}
                            />
                            {errors.websiteDescription && (
                                <p className="text-red-500 text-sm mt-1">{errors.websiteDescription}</p>
                            )}
                        </div>

                        <div className="flex gap-3">
                            {/* Logo */}
                            <div>
                                <label className="block font-semibold mb-2">Logo</label>
                                <div className="relative inline-block">
                                    <img
                                        src={logoFile ? URL.createObjectURL(logoFile) : formData.logo || '/image.jpg'}
                                        className="w-32 h-32 object-contain border rounded"
                                    />
                                    <label className="absolute bottom-0 right-0 bg-green-600 text-white text-xs px-2 py-1 rounded cursor-pointer hover:bg-green-700">
                                        Change
                                        <input
                                            type="file"
                                            hidden
                                            accept="image/*"
                                            onChange={(e) => {
                                                setLogoFile(e.target.files?.[0] || null);
                                                setErrors((prev) => ({ ...prev, logo: undefined }));
                                            }}
                                        />
                                    </label>
                                </div>
                                {errors.logo && <p className="text-sm text-red-500 mt-2">{errors.logo}</p>}
                            </div>

                            {/* Favicon */}
                            <div>
                                <label className="block font-semibold mb-2">Favicon</label>
                                <div className="relative inline-block">
                                    <img
                                        src={
                                            faviconFile
                                                ? URL.createObjectURL(faviconFile)
                                                : formData.favicon || '/image.jpg'
                                        }
                                        className="w-32 h-32 object-contain border rounded"
                                    />
                                    <label className="absolute bottom-0 right-0 bg-green-600 text-white text-xs px-2 py-1 rounded cursor-pointer hover:bg-green-700">
                                        Change
                                        <input
                                            type="file"
                                            hidden
                                            accept="image/*"
                                            onChange={(e) => {
                                                setFaviconFile(e.target.files?.[0] || null);
                                                setErrors((prev) => ({ ...prev, favicon: undefined }));
                                            }}
                                        />
                                    </label>
                                </div>
                                {errors.favicon && <p className="text-sm text-red-500 mt-2">{errors.favicon}</p>}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Menu / Holiday Deals */}
                <div>
                    <h2 className="text-xl font-semibold mb-6">Menu</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Holiday Deals Label</label>
                            <input
                                type="text"
                                value={formData.holidayDealsLabel}
                                onChange={(e) => handleChange('holidayDealsLabel', e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Seasonal Deals Label</label>
                            <input
                                type="text"
                                value={formData.seasonalDealsLabel}
                                onChange={(e) => handleChange('seasonalDealsLabel', e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                        </div>
                    </div>
                </div>

                {/* Admin Info */}
                <div>
                    <h2 className="text-xl font-semibold mb-6">Admin Info</h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input
                                type="email"
                                value={formData.adminEmail}
                                onChange={(e) => handleChange('adminEmail', e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            {errors.adminEmail && <p className="text-red-500 text-sm mt-1">{errors.adminEmail}</p>}
                        </div>
                    </div>
                </div>

                {/* Social Links */}
                <div>
                    <h2 className="text-xl font-semibold mb-6">Social Links</h2>
                    <div className="space-y-4">
                        {(Object.keys(formData.socialLinks) as Array<keyof typeof formData.socialLinks>).map((key) => (
                            <div key={key}>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    {key.charAt(0).toUpperCase() + key.slice(1)}
                                </label>
                                <input
                                    type="url"
                                    value={formData.socialLinks[key]}
                                    onChange={(e) => handleSocialChange(key, e.target.value)}
                                    placeholder={`Enter ${key} URL`}
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                />
                                {socialErrors[key] && <p className="text-red-500 text-sm mt-1">{socialErrors[key]}</p>}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Buttons */}
                <div className="flex justify-end gap-3 pt-6 border-t">
                    <button
                        type="button"
                        onClick={() => window.location.reload()}
                        className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={saving}
                        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                    >
                        Save changes
                    </button>
                </div>
            </div>
        </div>
    );
}
