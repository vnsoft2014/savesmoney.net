import { Deal } from '@/types';

export type UpdateDealFn = <K extends keyof Deal>(id: number, field: K, value: Deal[K]) => void;

export type CheckingDuplicateState = {
    [dealId: number]: {
        purchaseLink?: boolean;
        shortDescription?: boolean;
    };
};
