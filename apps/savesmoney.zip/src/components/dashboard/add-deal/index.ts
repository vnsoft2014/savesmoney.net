export { default as AddDeal } from './AddDeal';
