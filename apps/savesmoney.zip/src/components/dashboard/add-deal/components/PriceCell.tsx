import { useDealContext } from '../DealContext';
import { Deal } from '../types';

type Props = {
    deal: Deal;
};

export default function PriceCell({ deal }: Props) {
    const { updateDeal, errors } = useDealContext();

    return (
        <>
            <td className="px-4 py-3">
                <input
                    type="number"
                    value={deal.originalPrice || ''}
                    onChange={(e) => updateDeal(deal.id, 'originalPrice', Number(e.target.value))}
                    placeholder="299"
                    min="0"
                    step="0.01"
                    className={`w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${
                        errors[deal.id]?.originalPrice ? 'border-red-500' : 'border-gray-300'
                    }`}
                />
                {errors[deal.id]?.originalPrice && (
                    <span className="text-xs text-red-500 block mt-1">{errors[deal.id].originalPrice}</span>
                )}
            </td>

            <td className="px-4 py-3">
                <input
                    type="number"
                    value={deal.discountPrice || ''}
                    onChange={(e) => updateDeal(deal.id, 'discountPrice', Number(e.target.value))}
                    placeholder="269"
                    min="0"
                    step="0.01"
                    className={`w-full px-3 py-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${
                        errors[deal.id]?.discountPrice ? 'border-red-500' : 'border-gray-300'
                    }`}
                />
                {errors[deal.id]?.discountPrice && (
                    <span className="text-xs text-red-500 block mt-1">{errors[deal.id].discountPrice}</span>
                )}
            </td>

            <td className="px-4 py-3">
                <input
                    type="text"
                    value={deal.percentageOff}
                    readOnly
                    placeholder="Auto"
                    className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-sm text-gray-600"
                />
            </td>
        </>
    );
}
