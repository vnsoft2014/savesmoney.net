import { useDealContext } from '../DealContext';
import { Deal } from '../types';

type Props = {
    deal: Deal;
};

export default function DealFlags({ deal }: Props) {
    const { updateDeal } = useDealContext();

    return (
        <td className="px-4 py-3 text-center">
            <div className="block">
                <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold mb-1">Trending Deals</span>
                    <input
                        type="checkbox"
                        checked={deal.hotTrend}
                        onChange={(e) => updateDeal(deal.id, 'hotTrend', e.target.checked)}
                        className="w-5 h-5 accent-blue-600"
                    />
                </div>

                <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold mb-1">Holiday Deals</span>
                    <input
                        type="checkbox"
                        checked={deal.holidayDeals}
                        onChange={(e) => updateDeal(deal.id, 'holidayDeals', e.target.checked)}
                        className="w-5 h-5 accent-green-600"
                    />
                </div>

                <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold mb-1">Seasonal Deals</span>
                    <input
                        type="checkbox"
                        checked={deal.seasonalDeals}
                        onChange={(e) => updateDeal(deal.id, 'seasonalDeals', e.target.checked)}
                        className="w-5 h-5 accent-green-600"
                    />
                </div>

                <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold mb-1">Coupon</span>
                    <input
                        type="checkbox"
                        checked={deal.coupon}
                        onChange={(e) => updateDeal(deal.id, 'coupon', e.target.checked)}
                        className="w-5 h-5 accent-purple-600"
                    />
                </div>

                <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold mb-1">Clearance</span>
                    <input
                        type="checkbox"
                        checked={deal.clearance}
                        onChange={(e) => updateDeal(deal.id, 'clearance', e.target.checked)}
                        className="w-5 h-5 accent-red-600"
                    />
                </div>
                <div className="text-left">
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Tags:</label>

                    <textarea
                        rows={3}
                        placeholder="Enter tags, separated by commas"
                        onChange={(e) => updateDeal(deal.id, 'tags', e.target.value)}
                        className="
                            w-full
                            px-3 py-2
                            text-sm
                            border border-gray-300
                            rounded-md
                            resize-none
                            focus:outline-none
                            focus:ring-2
                            focus:ring-blue-500
                            focus:border-transparent
                            placeholder:text-gray-400
                        "
                    />
                </div>
            </div>
        </td>
    );
}
