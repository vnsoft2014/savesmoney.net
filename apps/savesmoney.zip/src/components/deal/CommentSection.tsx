'use client';

import { useState } from 'react';
import { CommentForm, CommentList } from './components';

export default function CommentSection({ dealId }: { dealId: string }) {
    const [refreshKey, setRefreshKey] = useState(0);

    return (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <CommentForm dealId={dealId} onSuccess={() => setRefreshKey((prev) => prev + 1)} />

            <CommentList dealId={dealId} refreshKey={refreshKey} />
        </div>
    );
}
