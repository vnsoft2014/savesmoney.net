'use client';

import Cookies from 'js-cookie';
import { useState } from 'react';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { RootState } from '@/store/store';
import { UserData } from '@/types';
import DealAlertSchema from '../seo/DealAlertSchema';

const CHANNELS = ['email'];

type FormErrors = {
    keywords?: string;
    name?: string;
    email?: string;
    channel?: string;
};

const DealAlert = () => {
    const [errors, setErrors] = useState<FormErrors>({});

    const [keywords, setKeywords] = useState('');
    const [channel, setChannel] = useState('email');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const [guestName, setGuestName] = useState('');
    const [guestEmail, setGuestEmail] = useState('');

    const user = useSelector((state: RootState) => state.User.userData) as UserData | null;

    const token = Cookies.get('token');
    const isSignin = !!(token && user);

    const submitName = isSignin ? user?.name : guestName;
    const submitEmail = isSignin ? user?.email : guestEmail;

    const validateForm = () => {
        const newErrors: FormErrors = {};

        if (!keywords.trim()) {
            newErrors.keywords = 'Please enter keywords.';
        }

        if (!submitName || !submitName.trim()) {
            newErrors.name = 'Please enter your name.';
        }

        if (!submitEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(submitEmail)) {
            newErrors.email = 'Please enter a valid email.';
        }

        if (!CHANNELS.includes(channel)) {
            newErrors.channel = 'Please select a valid channel.';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validateForm()) return;

        setIsSubmitting(true);

        try {
            const payload = {
                keywords: keywords.split(',').map((k) => k.trim()),
                channel,
                name: submitName,
                email: submitEmail,
                user: isSignin ? user?._id : null,
            };

            const res = await fetch('/api/deal-alert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.message || 'Something went wrong.');
            }

            toast.success('Deal alert created successfully!');
            setKeywords('');
            setChannel('email');
            setGuestName('');
            setGuestEmail('');
            setErrors({});
        } catch (err: any) {
            toast.error(err.message || 'Failed to create alert.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <>
            <DealAlertSchema />
            <div className="min-h-screen bg-gray-50 px-4 py-8">
                <div className="mx-auto max-w-4xl">
                    <div className="mb-6 rounded-lg bg-white p-6 shadow-md">
                        <h1 className="mb-0 text-xl font-bold text-gray-800">Deal Alert 🔔</h1>
                    </div>

                    <div className="rounded-lg bg-white p-6 shadow-md">
                        <h2 className="mb-6 text-lg font-bold text-gray-800">Add your Alert</h2>

                        <div className="space-y-4">
                            <div>
                                <label className="mb-2 block text-sm font-semibold text-gray-700">Keywords</label>
                                <input
                                    type="text"
                                    value={keywords}
                                    onChange={(e) => setKeywords(e.target.value)}
                                    placeholder="keywords for an alert"
                                    className="w-full rounded-md border border-gray-300 px-4 py-2 outline-none transition focus:border-transparent focus:ring-2 focus:ring-blue-500"
                                />

                                {errors.keywords && <p className="mt-1 text-sm text-red-600">{errors.keywords}</p>}
                            </div>

                            <div>
                                <label className="mb-2 block text-sm font-semibold text-gray-700">Channel</label>
                                <select
                                    value={channel}
                                    onChange={(e) => setChannel(e.target.value)}
                                    className="w-full rounded-md border border-gray-300 bg-white px-4 py-2 outline-none transition focus:border-transparent focus:ring-2 focus:ring-blue-500"
                                >
                                    {CHANNELS.map((ch) => (
                                        <option key={ch} value={ch}>
                                            {ch.toUpperCase()}
                                        </option>
                                    ))}
                                </select>

                                {errors.channel && <p className="mt-1 text-sm text-red-600">{errors.channel}</p>}
                            </div>

                            <div>
                                <label className="mb-2 block text-sm font-semibold text-gray-700">Name</label>
                                <input
                                    type="text"
                                    value={isSignin ? (user?.name ?? '') : guestName}
                                    onChange={(e) => !isSignin && setGuestName(e.target.value)}
                                    readOnly={isSignin}
                                    placeholder="Your name"
                                    className={`w-full rounded-md border px-4 py-2 ${
                                        isSignin ? 'bg-gray-100 cursor-not-allowed' : 'border-gray-300'
                                    }`}
                                />
                                {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name}</p>}
                            </div>

                            <div>
                                <label className="mb-2 block text-sm font-semibold text-gray-700">Email</label>
                                <input
                                    type="email"
                                    value={isSignin ? (user?.email ?? '') : guestEmail}
                                    onChange={(e) => !isSignin && setGuestEmail(e.target.value)}
                                    readOnly={isSignin}
                                    placeholder="you@example.com"
                                    className={`w-full rounded-md border px-4 py-2 ${
                                        isSignin ? 'bg-gray-100 cursor-not-allowed' : 'border-gray-300'
                                    }`}
                                />
                                {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
                            </div>

                            <div>
                                <button
                                    onClick={handleSubmit}
                                    disabled={isSubmitting}
                                    className="rounded-md bg-blue-600 px-6 py-3 font-semibold text-white shadow-md transition duration-200 hover:bg-blue-700 hover:shadow-lg disabled:cursor-not-allowed disabled:bg-blue-400"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default DealAlert;
