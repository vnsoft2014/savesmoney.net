import { PopularDeals } from '../deals';
import GoogleAds from '../widgets/Ads';

const Sidebar = () => {
    return (
        <aside className="xl:col-span-1 lg:col-span-2 lg:border-l md:mt-4 lg:mt-0 border-gray-200 min-h-screen px-3 pt-6 pb-3">
            <div className="sticky top-4 space-y-4">
                <GoogleAds slot="2013037708" />
                <PopularDeals />
            </div>
        </aside>
    );
};

export default Sidebar;
