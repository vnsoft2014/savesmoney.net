module.exports.SITE = {
  name: 'SavesMoney',

  origin: 'https://tailnext.vercel.app',
  basePathname: '/',
  trailingSlash: false,

  title: 'Saving money with Big Discounts',
  description: 'Discover the best verified deals, coupons, and discounts from trusted stores. Save money every day with SavesMoney.Net.',
};
