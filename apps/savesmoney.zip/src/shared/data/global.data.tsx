import { AnnouncementProps, HeaderProps } from '../types';

// Announcement data
export const announcementData: AnnouncementProps = {
    title: 'NEW!',
    callToAction: {
        text: 'Saving Money with Big Deals',
        href: '#',
    },
};

// Header data
export const headerData: HeaderProps = {
    links: [
        {
            label: 'Deals',
            href: '/deals',
            icon: 'chevron-down',
            links: [],
        },
        {
            label: 'Expiring Soon',
            href: '/expiring-soon',
        },
        {
            label: 'Trending Deals',
            href: '/trending-deals',
        },
        {
            label: 'Holiday Deals',
            href: '/holiday-deals',
        },
        {
            label: 'Seasonal Deals',
            href: '/seasonal-deals',
        },
    ],
    topHeaderLinks: [
        {
            label: 'Deal Alert',
            href: '/deal-alert',
        },
        {
            label: 'Contact',
            href: '/contact',
        },
    ],
    actions: [
        {
            text: 'Admin',
            href: '/dashboard',
            targetBlank: true,
        },
    ],
};
