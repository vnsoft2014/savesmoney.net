import { DealTypeData } from '@/types';

export const dealTypes: DealTypeData[] = [
    {
        _id: '6956911f6a21d3976431d2a8',
        name: 'Clothes',
        slug: 'clothes',
    },
    {
        _id: '695694a58ad0acfed51c278a',
        name: 'Electronics',
        slug: 'electronics',
    },
    {
        _id: '695698c78ad0acfed51c27a7',
        name: 'Grocery',
        slug: 'grocery',
    },
    {
        _id: '695698d38ad0acfed51c27ae',
        name: 'Household items',
        slug: 'household-items',
    },
    {
        _id: '695698f98ad0acfed51c27b5',
        name: 'Miscellaneous',
        slug: 'miscellaneous',
    },
    {
        _id: '695699068ad0acfed51c27bc',
        name: 'Fashion',
        slug: 'fashion',
    },
    {
        _id: '695699278ad0acfed51c27c3',
        name: 'Cosmetics',
        slug: 'cosmetics',
    },
    {
        _id: '695699468ad0acfed51c27ca',
        name: 'Suplements',
        slug: 'suplements',
    },
    {
        _id: '695699578ad0acfed51c27d1',
        name: 'Baby Kids',
        slug: 'baby-kids',
    },
    {
        _id: '6957314eb41c873dae895700',
        name: 'Office Supplies',
        slug: 'office-supplies',
    },
];

export const dealLinks = dealTypes.map((item) => ({
    label: item.name,
    href: `/deals/${item.slug}-${item._id}`,
}));
