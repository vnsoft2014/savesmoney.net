import DealsFilters from '@/components/deal/components/DealsFilters';
import DealsListing from '@/components/deals/DealsListing';
import Sidebar from '@/components/layout/Sidebar';
import Breadcrumb from '@/components/widgets/Breadcrumb';
import { getDealTypes } from '@/services/admin/deal-type';
import { getStores } from '@/services/admin/store';
import { getActiveDeals } from '@/services/comment/deal';
import { SITE } from '@/utils/site';
import { FileText, Home } from 'lucide-react';
import { Metadata } from 'next';

export const metadata: Metadata = {
    title: `Holiday Deals | ${SITE.name}`,
};

interface PageProps {
    searchParams?: { [key: string]: string | string[] | undefined };
}

const Page = async ({ searchParams }: PageProps) => {
    const initialDealType = typeof searchParams?.dealType === 'string' ? searchParams.dealType : '';
    const initialStore = typeof searchParams?.store === 'string' ? searchParams.store : '';
    const pageNum = typeof searchParams?.page === 'string' ? parseInt(searchParams.page) : 1;

    const [dealListResponse, dealTypes, stores] = await Promise.all([
        getActiveDeals(initialDealType, initialStore, pageNum, {
            holidayDeals: true,
        }),
        getDealTypes(),
        getStores(),
    ]);

    const breadcrumbItems = [
        {
            label: 'Home',
            href: '/',
            icon: <Home className="w-4 h-4 mr-2" />,
        },
        {
            label: 'Holiday Deals',
            icon: <FileText className="w-4 h-4 mr-2" />,
            active: true,
        },
    ];

    return (
        <div className="container min-h-screen pb-6">
            <div className="grid grid-cols-1 xl:grid-cols-5 lg:grid-cols-7">
                <main className="xl:col-span-4 lg:col-span-5 px-3">
                    <div className="flex flex-col xl:flex-row flex-wrap justify-between items-center gap-2 breadcrumbs md:mb-3 pt-6 pb-3">
                        <Breadcrumb items={breadcrumbItems} />

                        <DealsFilters showTypeFilter={true} dealTypes={dealTypes} stores={stores} />
                    </div>

                    <DealsListing
                        initDealListResponse={dealListResponse}
                        params={{
                            holidayDeals: true,
                        }}
                        dealTypeName="Holiday Deals"
                        dealTypeSlug="holiday-deals"
                    />
                </main>

                <Sidebar />
            </div>
        </div>
    );
};

export default Page;
