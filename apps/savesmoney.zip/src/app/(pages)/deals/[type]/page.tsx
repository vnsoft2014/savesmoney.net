import DealsFilters from '@/components/deal/components/DealsFilters';
import DealsListing from '@/components/deals/DealsListing';
import Sidebar from '@/components/layout/Sidebar';
import Breadcrumb from '@/components/widgets/Breadcrumb';
import { getDealTypeById, getDealTypes } from '@/services/admin/deal-type';
import { getStores } from '@/services/admin/store';
import { getActiveDeals } from '@/services/comment/deal';
import { DealTypeData } from '@/types';
import { getIdFromSlug } from '@/utils/utils';
import { FileText, Home } from 'lucide-react';
import { notFound } from 'next/navigation';

type Props = {
    params: Promise<{
        type: string;
    }>;
    searchParams?: Promise<{ [key: string]: string | string[] | undefined }>;
};

export async function generateMetadata({ params }: Props) {
    const { type: dealType } = await params;

    const dealTypeId = getIdFromSlug(dealType);

    const data = await getDealTypeById(dealTypeId);

    if (data?.success) {
        return {
            title: `${data.data.name} | SavesMoney`,
        };
    }

    return {
        title: 'Deal Type | SavesMoney',
    };
}

const Page = async ({ params, searchParams }: Props) => {
    const { type: dealType } = await params;

    const sp = searchParams ? await searchParams : {};

    const dealTypeId = getIdFromSlug(dealType);

    const initialStore = typeof sp.store === 'string' ? sp.store : '';
    const pageNum = typeof sp.page === 'string' ? parseInt(sp.page) : 1;

    if (!dealTypeId) {
        notFound();
    }

    const [initialDealsData, dealTypes, stores] = await Promise.all([
        getActiveDeals(dealTypeId, initialStore, pageNum),
        getDealTypes(),
        getStores(),
    ]);

    if (!initialDealsData?.success || !initialDealsData.data) {
        notFound();
    }

    const currentDealType = dealTypes.data.find((item: DealTypeData) => item._id === dealTypeId);

    const breadcrumbItems = [
        {
            label: 'Home',
            href: '/',
            icon: <Home className="w-4 h-4 mr-2" />,
        },
        {
            label: currentDealType?.name ?? 'Deals',
            icon: <FileText className="w-4 h-4 mr-2" />,
            active: true,
        },
    ];

    return (
        <div className="container min-h-screen mx-auto pb-6">
            <div className="grid grid-cols-1 lg:grid-cols-5">
                <main className="lg:col-span-4 px-3">
                    <div className="flex flex-col xl:flex-row flex-wrap justify-between items-center gap-2 breadcrumbs md:mb-3 py-3">
                        <Breadcrumb items={breadcrumbItems} />

                        <DealsFilters showTypeFilter={false} dealTypes={[]} stores={stores.data} />
                    </div>

                    <DealsListing
                        initialDealsData={initialDealsData}
                        initialDealType={dealTypeId}
                        initialStore={initialStore}
                        dealTypeName={currentDealType.name}
                        dealTypeSlug={currentDealType.slug}
                    />
                </main>

                <Sidebar />
            </div>
        </div>
    );
};

export default Page;
