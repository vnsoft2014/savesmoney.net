import { Announcement, MainNav } from '@/components/header';
import { Footer } from '@/components/layout';
import ChatWidget from '@/components/widgets/ChatWidget';
import DealPopup from '@/components/widgets/DealPopup';

export default function SiteLayout({ children }: { children: React.ReactNode }) {
    return (
        <>
            <header>
                <Announcement />
                <MainNav />
            </header>
            <main className="bg-gray-100">{children}</main>
            <Footer />
            <ChatWidget />
            <DealPopup />
        </>
    );
}
