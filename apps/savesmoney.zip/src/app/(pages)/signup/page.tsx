import { Metadata } from 'next';
import SignUpForm from '@/components/auth/signup/SignUpForm';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Sign Up | ${SITE.name}`,
};

const Page = () => {
    return <SignUpForm />;
};

export default Page;
