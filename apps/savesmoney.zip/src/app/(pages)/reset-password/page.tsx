import { Metadata } from 'next';
import ResetPasswordForm from '@/components/auth/reset-password/ResetPasswordForm';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Reset Password | ${SITE.name}`,
};

const Page = () => {
    return <ResetPasswordForm />;
};

export default Page;
