import { Metadata } from 'next';
import ForgotPasswordForm from '@/components/auth/forgot-password/ForgotPasswordForm';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Forgot Password | ${SITE.name}`,
};

const Page = () => {
    return <ForgotPasswordForm />;
};

export default Page;
