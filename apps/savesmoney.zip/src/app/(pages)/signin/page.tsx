import { Metadata } from 'next';
import SignInForm from '@/components/auth/signin/SignInForm';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Sign In | ${SITE.name}`,
};

const Page = () => {
    return <SignInForm />;
};

export default Page;
