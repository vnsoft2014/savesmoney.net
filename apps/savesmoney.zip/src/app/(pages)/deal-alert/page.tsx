import type { Metadata } from 'next';
import DealAlert from '@/components/deal/DealAlert';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Deal Alert | ${SITE.name}`,
};

const Page = () => {
    return <DealAlert />;
};

export default Page;
