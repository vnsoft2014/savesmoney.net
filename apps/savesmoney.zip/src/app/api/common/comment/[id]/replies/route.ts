import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/DB/connectDB';
import Comment from '@/models/Comment';
import Joi from 'joi';
import mongoose, { PipelineStage } from 'mongoose';

export const dynamic = 'force-dynamic';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

const paramsSchema = Joi.object({
    id: Joi.string().length(24).hex().required(),
});

const querySchema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(20).default(5),
    sort: Joi.string().valid('oldest', 'newest').default('oldest'),
});

export async function GET(req: NextRequest, { params }: Props) {
    try {
        const { error: paramError } = paramsSchema.validate(await params);
        if (paramError) {
            return NextResponse.json({ success: false, message: paramError.message }, { status: 400 });
        }

        const { searchParams } = new URL(req.url);
        const { value: query, error: queryError } = querySchema.validate({
            page: searchParams.get('page'),
            limit: searchParams.get('limit'),
            sort: searchParams.get('sort'),
        });

        if (queryError) {
            return NextResponse.json({ success: false, message: queryError.message }, { status: 400 });
        }

        const { page, limit, sort } = query;

        await connectDB();

        const { id } = await params;

        const parentId = new mongoose.Types.ObjectId(id);
        const skip = (page - 1) * limit;

        const sortStage: PipelineStage.Sort['$sort'] = sort === 'newest' ? { createdAt: -1 } : { createdAt: 1 };

        const replies = await Comment.aggregate([
            { $match: { parentId, isApproved: true } },
            { $sort: sortStage },
            { $skip: skip },
            { $limit: limit },

            {
                $lookup: {
                    from: 'users',
                    let: { userId: '$user' },
                    pipeline: [
                        { $match: { $expr: { $eq: ['$_id', '$$userId'] } } },
                        { $project: { avatar: 1, name: 1, _id: 1 } },
                    ],
                    as: 'user',
                },
            },
            {
                $unwind: { path: '$user', preserveNullAndEmptyArrays: true },
            },

            {
                $lookup: {
                    from: 'comments',
                    let: { commentId: '$_id' },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [{ $eq: ['$parentId', '$$commentId'] }, { $eq: ['$isApproved', true] }],
                                },
                            },
                        },
                        { $count: 'count' },
                    ],
                    as: 'repliesMeta',
                },
            },
            {
                $addFields: {
                    repliesCount: { $ifNull: [{ $arrayElemAt: ['$repliesMeta.count', 0] }, 0] },
                },
            },
            { $project: { repliesMeta: 0 } },
        ]);

        const total = await Comment.countDocuments({ parentId, isApproved: true });

        return NextResponse.json({
            success: true,
            data: replies,
            pagination: { page, limit, total, hasMore: page * limit < total },
        });
    } catch (err) {
        console.error('GET REPLIES ERROR:', err);
        return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
    }
}
