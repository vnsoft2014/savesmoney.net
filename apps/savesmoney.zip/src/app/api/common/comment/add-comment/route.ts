import connectDB from '@/DB/connectDB';
import Comment from '@/models/Comment';
import User from '@/models/User';
import Joi from 'joi';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

const CommentSchema = Joi.object({
    deal: Joi.string().required(),
    user: Joi.string().optional().allow(null),
    username: Joi.string().required().trim(),
    userEmail: Joi.string().email().required().trim().lowercase(),
    content: Joi.string().required().trim(),
    parentId: Joi.string().optional().allow(null),
    ipAddress: Joi.string().optional().allow(null),
});

export async function POST(req: Request) {
    await connectDB();

    const data = await req.json();

    const { error, value } = CommentSchema.validate(data, {
        abortEarly: false,
        stripUnknown: true,
    });

    if (error) {
        return NextResponse.json(
            {
                success: false,
                message: 'Validation failed',
                errors: error.details.map((d) => d.message.replace(/['"]+/g, '')),
            },
            { status: 400 },
        );
    }

    try {
        if (value.user) {
            const user = await User.findById(value.user).select('isBlocked');

            if (!user) {
                return NextResponse.json(
                    {
                        success: false,
                        message: 'User not found',
                    },
                    { status: 404 },
                );
            }

            if (user.isBlocked) {
                return NextResponse.json(
                    {
                        success: false,
                        message: 'Your account has been blocked from commenting',
                    },
                    { status: 403 },
                );
            }
        }

        const comment = new Comment({
            ...value,
            isApproved: true, //!!isAuthenticated,
            ipAddress: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || null,
        });

        await comment.save();

        return NextResponse.json({
            success: true,
            message: 'Comment added successfully!',
            comment: comment,
        });
    } catch (err) {
        return NextResponse.json(
            {
                success: false,
                message: 'Internal server error',
            },
            { status: 500 },
        );
    }
}
