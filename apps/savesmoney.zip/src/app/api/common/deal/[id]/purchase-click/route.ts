import connectDB from '@/DB/connectDB';
import DealStats from '@/models/DealStats';
import { NextResponse } from 'next/server';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

export async function POST(req: Request, { params }: Props) {
    await connectDB();

    const { id: dealId } = await params;

    const updated = await DealStats.findOneAndUpdate(
        {
            dealId,
        },
        {
            $inc: { purchaseClicks: 1 },
        },
        { upsert: true, new: true },
    );

    return NextResponse.json({
        success: true,
        counted: !!updated,
    });
}
