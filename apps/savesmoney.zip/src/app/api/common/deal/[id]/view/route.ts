import { NextResponse } from 'next/server';
import DealStats from '@/models/DealStats';
import connectDB from '@/DB/connectDB';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

export async function POST(_: Request, { params }: Props) {
    await connectDB();

    const { id } = await params;

    await DealStats.findOneAndUpdate({ dealId: id }, { $inc: { views: 1 } }, { upsert: true, new: true });

    return NextResponse.json({});
}
