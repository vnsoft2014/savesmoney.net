import connectDB from '@/DB/connectDB';
import { NextResponse } from 'next/server';
import Deal from '@/models/Deal';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: Props) {
    await connectDB();

    try {
        const { searchParams } = new URL(req.url);
        const populate = searchParams.get('populate') === 'true';

        const { id } = await params;

        let query = Deal.findById(id);

        if (populate) {
            query = query.populate('dealType').populate('store').populate('author');
        }

        const getData = await query.lean();

        if (getData) {
            return NextResponse.json({ success: true, data: getData });
        } else {
            return NextResponse.json({ status: 204, success: false, message: 'No Deal found.' });
        }
    } catch (error) {
        console.log('Error in getting deal by id:', error);
        return NextResponse.json({ status: 500, success: false, message: 'Something went wrong. Please try again!' });
    }
}
