import { NextResponse } from 'next/server';
import connectDB from '@/DB/connectDB';
import DealType from '@/models/DealType';

export const dynamic = 'force-dynamic';

export async function GET() {
    try {
        await connectDB();

        const dealTypes = await DealType.find();

        return NextResponse.json({
            success: true,
            data: dealTypes,
        });
    } catch (error) {
        console.error(error);
        return NextResponse.json({ success: false, message: 'Failed to fetch deal types' }, { status: 500 });
    }
}
