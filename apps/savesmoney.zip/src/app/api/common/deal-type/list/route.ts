import { NextResponse } from 'next/server';
import connectDB from '@/DB/connectDB';
import DealType from '@/models/DealType';
import Joi from 'joi';

export const dynamic = 'force-dynamic';

const QuerySchema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(20),
    search: Joi.string().allow('').default(''),
    sortField: Joi.string().valid('_id', 'createdAt', 'name').default('_id'),
    sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
});

export async function GET(req: Request) {
    try {
        await connectDB();

        const { searchParams } = new URL(req.url);

        const queryObj = {
            page: searchParams.get('page'),
            limit: searchParams.get('limit'),
            search: searchParams.get('search'),
            sortField: searchParams.get('sortField'),
            sortOrder: searchParams.get('sortOrder'),
        };

        const { value, error } = QuerySchema.validate(queryObj, {
            abortEarly: false,
        });

        if (error) {
            return NextResponse.json(
                {
                    success: false,
                    message: 'Invalid query params',
                    errors: error.details.map((e) => e.message),
                },
                { status: 400 },
            );
        }

        const { page, limit, search, sortField, sortOrder } = value;

        const skip = (page - 1) * limit;

        // ==========================
        // Filter
        // ==========================
        const filter: any = {};

        if (search) {
            filter.$or = [{ name: { $regex: search, $options: 'i' } }, { slug: { $regex: search, $options: 'i' } }];
        }

        // ==========================
        // Sort
        // ==========================
        const sort: Record<string, 1 | -1> = {
            [sortField]: sortOrder === 'asc' ? 1 : -1,
        };

        const [data, total] = await Promise.all([
            DealType.find(filter).sort(sort).skip(skip).limit(limit),
            DealType.countDocuments(filter),
        ]);

        return NextResponse.json({
            success: true,
            data,
            pagination: {
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit),
            },
        });
    } catch (error) {
        console.error('GET DEAL TYPE ERROR:', error);
        return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
    }
}
