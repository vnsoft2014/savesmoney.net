import { ADMIN_ONLY } from '@/constants/user';
import connectDB from '@/DB/connectDB';
import { assertRole, authCheck } from '@/middleware/authCheck';
import { withObjectId } from '@/middleware/withObjectId';
import Subscriber from '@/models/Subscriber';
import { NextResponse } from 'next/server';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

export const DELETE = withObjectId(async (req: Request, { params }: Props) => {
    try {
        await connectDB();

        const role = await authCheck(req);
        if (!assertRole(role, ADMIN_ONLY)) {
            return NextResponse.json(
                {
                    success: false,
                    message: 'You are not authorized.',
                },
                { status: 403 },
            );
        }

        const { id } = await params;

        const dealType = await Subscriber.findById(id);

        if (!dealType) {
            return NextResponse.json(
                {
                    success: false,
                    message: 'Deal Subscriber not found',
                },
                { status: 404 },
            );
        }

        await Subscriber.findByIdAndDelete(id);

        return NextResponse.json({
            success: true,
            message: 'Deal Subscriber deleted successfully',
        });
    } catch (error) {
        return NextResponse.json(
            {
                success: false,
                message: 'Server error',
                error,
            },
            { status: 500 },
        );
    }
});
