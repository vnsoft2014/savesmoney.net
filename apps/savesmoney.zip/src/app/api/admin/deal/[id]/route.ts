import { ADMIN_ONLY, ADMIN_ROLES } from '@/constants/user';
import connectDB from '@/DB/connectDB';
import { assertRole, authCheck } from '@/middleware/authCheck';
import Deal from '@/models/Deal';
import Joi from 'joi';
import mongoose from 'mongoose';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

type Props = {
    params: Promise<{
        id: string;
    }>;
};

const UpdateDealSchema = Joi.object({
    _id: Joi.string().required(),

    picture: Joi.string().optional(),

    dealType: Joi.array().items(Joi.string()).optional(),

    store: Joi.string().optional(),

    expiredDate: Joi.string()
        .optional()
        .allow(null, '')
        .custom((value, helpers) => {
            const { disableExpireAt, coupon, clearance } = helpers.state.ancestors[0];

            const mustDisable = coupon === true || clearance === true || disableExpireAt === true;

            if (mustDisable) {
                if (value) {
                    return helpers.error('any.invalid', {
                        message: 'Expired date must be null when disableExpireAt is true',
                    });
                }
                return null;
            }

            if (!value) {
                return helpers.error('any.required', {
                    message: 'Expired date is required',
                });
            }

            const date = new Date(value);
            if (isNaN(date.getTime())) {
                return helpers.error('date.base', {
                    message: 'Expired date must be a valid date',
                });
            }

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            date.setHours(0, 0, 0, 0);

            if (date < today) {
                return helpers.error('date.min', {
                    message: 'Expired date cannot be in the past',
                });
            }

            return value;
        }),

    shortDescription: Joi.string().required(),

    originalPrice: Joi.number().min(0).required(),

    discountPrice: Joi.number().min(0).required(),

    percentageOff: Joi.string().optional(),

    purchaseLink: Joi.string().uri().optional(),

    description: Joi.string().optional(),

    hotTrend: Joi.boolean().optional(),
    holidayDeals: Joi.boolean().optional(),

    seasonalDeals: Joi.boolean().optional(),

    coupon: Joi.boolean().default(false),
    clearance: Joi.boolean().default(false),

    disableExpireAt: Joi.boolean().optional(),
})
    .min(2)
    .custom((value, helpers) => {
        if (
            typeof value.originalPrice === 'number' &&
            typeof value.discountPrice === 'number' &&
            value.discountPrice >= value.originalPrice
        ) {
            return helpers.error('any.invalid', {
                message: 'Discount Price must be less than Original Price',
            });
        }

        return value;
    });

export async function PATCH(req: Request, { params }: Props) {
    try {
        await connectDB();

        const role = await authCheck(req);
        if (!assertRole(role, ADMIN_ROLES)) {
            return NextResponse.json({
                success: false,
                message: 'You are not authorized.',
            });
        }

        const data = await req.json();

        const { error } = UpdateDealSchema.validate(data, {
            abortEarly: false,
        });

        if (error) {
            return NextResponse.json({
                success: false,
                message: 'Validation failed',
                errors: error.details.map((d) => d.message.replace(/['"]+/g, '')),
            });
        }

        const { id: dealId } = await params;

        const {
            picture,
            dealType,
            store,
            expiredDate,
            shortDescription,
            originalPrice,
            discountPrice,
            percentageOff,
            purchaseLink,
            description,
            hotTrend,
            holidayDeals,
            seasonalDeals,
            coupon,
            clearance,
            disableExpireAt,
        } = data;

        const duplicateQuery: any = {
            _id: { $ne: new mongoose.Types.ObjectId(dealId) },
            $or: [],
        };

        if (purchaseLink !== undefined) {
            duplicateQuery.$or.push({ purchaseLink });
        }

        if (shortDescription !== undefined) {
            duplicateQuery.$or.push({ shortDescription });
        }

        if (duplicateQuery.$or.length > 0) {
            const duplicateDeal = await Deal.findOne(duplicateQuery).select('purchaseLink shortDescription');

            if (duplicateDeal) {
                return NextResponse.json(
                    {
                        success: false,
                        message: 'Duplicate data detected',
                        duplicateFields: {
                            purchaseLink: purchaseLink !== undefined && duplicateDeal.purchaseLink === purchaseLink,
                            shortDescription:
                                shortDescription !== undefined && duplicateDeal.shortDescription === shortDescription,
                        },
                    },
                    { status: 409 },
                );
            }
        }

        const updateData: any = {};

        if (picture !== undefined) updateData.image = picture;
        if (dealType !== undefined) updateData.dealType = dealType;
        if (store !== undefined) updateData.store = store;

        const finalDisableExpireAt = coupon === true || clearance === true ? true : Boolean(disableExpireAt);

        if (finalDisableExpireAt === true) {
            updateData.expireAt = null;
        }

        if (finalDisableExpireAt === false && expiredDate) {
            updateData.expireAt = expiredDate.endsWith('T23:59:59.000Z')
                ? new Date(expiredDate)
                : new Date(expiredDate + 'T23:59:59.000Z');
        }

        if (shortDescription !== undefined) updateData.shortDescription = shortDescription;

        if (originalPrice !== undefined) updateData.originalPrice = originalPrice;

        if (discountPrice !== undefined) updateData.discountPrice = discountPrice;

        if (percentageOff !== undefined) updateData.percentageOff = percentageOff;

        if (purchaseLink !== undefined) updateData.purchaseLink = purchaseLink;

        if (description !== undefined) updateData.description = description;

        if (hotTrend !== undefined) updateData.hotTrend = hotTrend;

        if (holidayDeals !== undefined) updateData.holidayDeals = holidayDeals;

        if (seasonalDeals !== undefined) updateData.seasonalDeals = seasonalDeals;

        if (coupon !== undefined) updateData.coupon = coupon;

        if (clearance !== undefined) updateData.clearance = clearance;

        if (disableExpireAt !== undefined) updateData.disableExpireAt = disableExpireAt;

        const updatedDeal = await Deal.findByIdAndUpdate(dealId, updateData, { new: true, runValidators: true });

        if (!updatedDeal) {
            return NextResponse.json({
                success: false,
                message: 'Deal not found',
            });
        }

        return NextResponse.json({
            success: true,
            message: 'Deal updated successfully!',
            data: updatedDeal,
        });
    } catch (err) {
        console.error('Update deal error:', err);
        return NextResponse.json({
            success: false,
            message: 'Something went wrong',
            error: err instanceof Error ? err.message : 'Unknown error',
        });
    }
}

export async function DELETE(req: Request, { params }: Props) {
    try {
        await connectDB();

        const role = await authCheck(req);
        if (!assertRole(role, ADMIN_ONLY)) {
            const { id } = await params;

            const deleteData = await Deal.findByIdAndDelete(id);

            if (deleteData) {
                return NextResponse.json({ success: true, message: 'Deal Deleted successfully!' });
            } else {
                return NextResponse.json({ success: false, message: 'Failed to Delete the Deal. Please try again!' });
            }
        } else {
            return NextResponse.json({ success: false, message: 'You are not authorized.' });
        }
    } catch (error) {
        console.log('Error in deleting a new Deal:', error);
        return NextResponse.json({ success: false, message: 'Something went wrong. Please try again!' });
    }
}
