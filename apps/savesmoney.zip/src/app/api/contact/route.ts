import { NextResponse } from 'next/server';
import Joi from 'joi';
import { sendMail } from '@/utils/sendMail';
import Settings from '@/models/Settings';

const contactSchema = Joi.object({
    name: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().required(),
    phone: Joi.string().optional(),
    radio: Joi.string().allow(''),
    message: Joi.string().allow(''),
    checkboxes: Joi.array().items(Joi.string()),
});

export async function POST(req: Request) {
    try {
        const body = await req.json();

        const { error, value } = contactSchema.validate(body, {
            abortEarly: false,
        });

        if (error) {
            return NextResponse.json(
                { message: 'Validation error', errors: error.details.map((e) => e.message) },
                { status: 400 },
            );
        }

        const settings = await Settings.findOne().lean();

        if (settings.adminEmail) {
            throw new Error();
        }

        await sendMail({
            to: settings.adminEmail,
            subject: 'New Contact Form Submission',
            html: `
        <h2>New Contact Message</h2>
        <p><strong>Name:</strong> ${value.name} ${value.lastName}</p>
        <p><strong>Email:</strong> ${value.email}</p>
        <p><strong>Phone:</strong> ${value.phone || '-'}</p>
        <p><strong>Service:</strong> ${value.radio || '-'}</p>
        <p><strong>Options:</strong> ${(value.checkboxes || []).join(', ')}</p>
        <p><strong>Message:</strong></p>
        <p>${value.message || '-'}</p>
      `,
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('CONTACT ERROR:', error);
        return NextResponse.json({ success: false, message: 'Failed to send message' }, { status: 500 });
    }
}
