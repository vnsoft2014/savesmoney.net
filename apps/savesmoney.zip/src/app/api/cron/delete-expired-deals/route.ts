import { Brackets } from 'lucide-react';
import { NextResponse } from 'next/server';
import connectDB from '@/DB/connectDB';
import Deal from '@/models/Deal';

const CRON_SECRET = process.env.CRON_SECRET;
const BATCH_SIZE = 300;

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const token = searchParams.get('token');

    if (token !== CRON_SECRET) {
        return NextResponse.json({ success: false }, { status: 401 });
    }

    try {
        await connectDB();

        const now = new Date();
        const oneMonthAgo = new Date();
        oneMonthAgo.setDate(now.getDate() - 1);

        let totalDeleted = 0;
        let hasMore = true;

        console.log(oneMonthAgo);

        while (hasMore) {
            const deals = await Deal.find({ dealExpireAt: { $lt: oneMonthAgo } }, { _id: 1 })
                .limit(BATCH_SIZE)
                .lean();

            if (deals.length === 0) {
                hasMore = false;

                break;
            }

            const ids = deals.map((d) => d._id);

            console.log(ids);

            const result = await Deal.deleteMany({
                _id: { $in: ids },
            });

            totalDeleted += result.deletedCount || 0;

            await new Promise((res) => setTimeout(res, 100));
        }

        return NextResponse.json({
            success: true,
            deletedCount: totalDeleted,
            message: 'Expired deals deleted successfully',
        });
    } catch (error) {
        console.error('Cron delete error:', error);
        return NextResponse.json({
            success: false,
            message: 'Delete expired deals failed',
        });
    }
}
