'use client';

import AddStoreForm from '@/components/dashboard/store/AddStoreForm';

export default function Page() {
    return <AddStoreForm />;
}
