'use client';

import { checkDuplicate, getDealById, updateDeal } from '@/services/admin/deal';
import { DealTypeData } from '@/types';
import { stripHtmlTags, toDateInputValue } from '@/utils/utils';
import Cookies from 'js-cookie';
import { ArrowLeft, Clipboard, Save, Upload } from 'lucide-react';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import React, { useEffect, useRef, useState } from 'react';
import { TailSpin } from 'react-loader-spinner';
import Select from 'react-select';
import { toast } from 'react-toastify';
import useSWR from 'swr';

import Loading from '@/components/loading';
import 'react-quill-new/dist/quill.snow.css';

interface Params {
    params: Promise<{
        id: string;
    }>;
}

type DealField = keyof Deal;
type DealErrors = Partial<Record<DealField, string>>;

type CheckingDuplicateState = {
    purchaseLink?: boolean;
    shortDescription?: boolean;
};

const ReactQuill = dynamic(() => import('react-quill-new'), {
    ssr: false,
});

let duplicateTimeout: ReturnType<typeof setTimeout> | null = null;

const debounceCheckDuplicate = (
    dealId: string,
    params: {
        purchaseLink?: string;
        shortDescription?: string;
    },
    setErrors: React.Dispatch<React.SetStateAction<any>>,
    setChecking: React.Dispatch<React.SetStateAction<CheckingDuplicateState>>,
) => {
    if (duplicateTimeout) {
        clearTimeout(duplicateTimeout);
    }

    duplicateTimeout = setTimeout(async () => {
        const { purchaseLink, shortDescription } = params;

        if (!purchaseLink && !shortDescription) {
            setErrors((prev: any) => ({
                ...prev,
                purchaseLink: undefined,
                shortDescription: undefined,
            }));

            setChecking((prev: any) => ({
                ...prev,
                purchaseLink: false,
                shortDescription: false,
            }));
            return;
        }

        setChecking((prev: any) => ({
            ...prev,
            purchaseLink: Boolean(purchaseLink),
            shortDescription: Boolean(shortDescription),
        }));

        try {
            const res = await checkDuplicate(shortDescription, purchaseLink);

            setErrors((prev: any) => ({
                ...prev,
                purchaseLink: purchaseLink
                    ? res?.isDuplicate
                        ? 'Purchase link already exists'
                        : undefined
                    : prev?.[dealId]?.purchaseLink,

                shortDescription: shortDescription
                    ? res?.isDuplicate
                        ? 'Short description already exists'
                        : undefined
                    : prev?.[dealId]?.shortDescription,
            }));
        } catch (err) {
            console.error('debounceCheckDuplicate error:', err);
        } finally {
            setChecking((prev: any) => ({
                ...prev,
                purchaseLink: false,
                shortDescription: false,
            }));
        }
    }, 500);
};

const ToggleSwitch = ({
    checked,
    onChange,
    label,
}: {
    checked: boolean;
    onChange: (value: boolean) => void;
    label: string;
}) => {
    return (
        <div className="flex items-center justify-between py-2">
            <span className="text-sm font-semibold text-gray-700">{label}</span>

            <button
                type="button"
                onClick={() => onChange(!checked)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${
                    checked ? 'bg-green-600' : 'bg-gray-300'
                }`}
            >
                <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                        checked ? 'translate-x-6' : 'translate-x-1'
                    }`}
                />
            </button>
        </div>
    );
};

export default async function Page({ params }: Params) {
    const { id } = await params;

    const [loader, setLoader] = useState(false);
    const [uploadingImage, setUploadingImage] = useState(false);
    const [isPasteFocused, setIsPasteFocused] = useState(false);

    const Router = useRouter();

    const [deal, setDeal] = useState<Deal | null>(null);
    const [errors, setErrors] = useState<DealErrors>({});

    const [dealTypes, setDealTypes] = useState<DealTypeData[]>([]);
    const [stores, setStores] = useState<{ _id: string; name: string }[]>([]);
    const [loadingMeta, setLoadingMeta] = useState(false);

    const [checkingDuplicate, setCheckingDuplicate] = useState<CheckingDuplicateState>({});

    const { data, isLoading } = useSWR(`/gettingDealByID/${id}`, () => getDealById(id));

    useEffect(() => {
        document.title = 'Update Deal | Admin Dashboard';

        return () => {
            if (duplicateTimeout) {
                clearTimeout(duplicateTimeout);
            }
        };
    }, []);

    useEffect(() => {
        if (data?.data) {
            const deal: Deal = {
                id: data.data._id,
                picture: data.data.image,
                dealType: data.data.dealType || [],
                store: data.data.store,
                expiredDate: data.data.expireAt,
                shortDescription: data.data.shortDescription,
                originalPrice: data.data.originalPrice,
                discountPrice: data.data.discountPrice,
                percentageOff: data.data.percentageOff,
                purchaseLink: data.data.purchaseLink,
                description: data.data.description,
                hotTrend: data.data.hotTrend,
                holidayDeals: data.data.holidayDeals,
                seasonalDeals: data.data.seasonalDeals,
                coupon: data.data.coupon,
                clearance: data.data.clearance,
                disableExpireAt: data.data.disableExpireAt,
            };
            setDeal(deal);
        }
    }, [data]);

    // Global paste event listener
    useEffect(() => {
        const handleGlobalPaste = async (e: ClipboardEvent) => {
            // Only handle if paste area is focused
            if (!isPasteFocused || uploadingImage) return;

            const items = e.clipboardData?.items;
            if (!items) return;

            for (let i = 0; i < items.length; i++) {
                const item = items[i];

                if (item.type.indexOf('image') !== -1) {
                    e.preventDefault();
                    const file = item.getAsFile();
                    if (file) {
                        const fakeEvent = {
                            target: {
                                files: [file],
                            },
                        };
                        await handleImageUpload(fakeEvent);
                    }
                    break;
                }
            }
        };

        document.addEventListener('paste', handleGlobalPaste);
        return () => {
            document.removeEventListener('paste', handleGlobalPaste);
        };
    }, [isPasteFocused, uploadingImage]);

    useEffect(() => {
        const fetchMetaData = async () => {
            try {
                setLoadingMeta(true);

                const token = Cookies.get('token');

                const [dealTypeRes, storeRes] = await Promise.all([
                    fetch('/api/common/deal-type/all', {
                        headers: { Authorization: `Bearer ${token}` },
                    }),
                    fetch('/api/common/store/all', {
                        headers: { Authorization: `Bearer ${token}` },
                    }),
                ]);

                const [dealTypeData, storeData] = await Promise.all([dealTypeRes.json(), storeRes.json()]);

                if (dealTypeData.success) {
                    setDealTypes(dealTypeData.data);
                } else {
                    toast.error('Failed to load deal types');
                }

                if (storeData.success) {
                    setStores(storeData.data);
                } else {
                    toast.error('Failed to load stores');
                }
            } catch (error) {
                console.error(error);
                toast.error('Error loading deal metadata');
            } finally {
                setLoadingMeta(false);
            }
        };

        fetchMetaData();
    }, []);

    const updateField = <K extends keyof Deal>(field: K, value: Deal[K]): void => {
        setDeal((deal) => {
            if (!deal) return null;

            const updatedDeal = { ...deal, [field]: value };

            // Auto-calculate percentage off when original or discount price changes
            if (field === 'originalPrice' || field === 'discountPrice') {
                const original = field === 'originalPrice' ? Number(value) : deal.originalPrice;
                const discount = field === 'discountPrice' ? Number(value) : deal.discountPrice;

                if (original > 0) {
                    // If discount is 0 or >= original, show 0% off
                    if (discount === 0 || discount >= original) {
                        updatedDeal.percentageOff = '0%';
                    } else if (discount > 0 && discount < original) {
                        // Calculate percentage for valid discount
                        const percentage = Math.round(((original - discount) / original) * 100);
                        updatedDeal.percentageOff = `${percentage}%`;
                    }
                }
            } else if (
                (field === 'coupon' && updatedDeal.coupon) ||
                (field === 'clearance' && updatedDeal.clearance) ||
                (field === 'disableExpireAt' && updatedDeal.disableExpireAt)
            ) {
                updatedDeal.expiredDate = null;
            }

            return updatedDeal;
        });

        // Clear field error
        if (errors[field]) {
            setErrors((prev) => ({
                ...prev,
                [field]: undefined,
            }));
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement> | any): Promise<void> => {
        const file = e.target.files?.[0];

        if (!file) return;

        // Validate file type
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];
        if (!validTypes.includes(file.type)) {
            toast.error('Invalid file type. Only JPEG, PNG, WEBP, and GIF are allowed.');
            return;
        }

        // Validate file size (max 5MB)
        const maxSize = 5 * 1024 * 1024;
        if (file.size > maxSize) {
            toast.error('File size too large. Maximum 5MB allowed.');
            return;
        }

        setUploadingImage(true);

        const reader = new FileReader();
        reader.onloadend = () => {
            updateField('picture', reader.result as string);
        };
        reader.readAsDataURL(file);

        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch('/api/upload/image', {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${Cookies.get('token')}`,
                },
                body: formData,
            });

            const result = await response.json();

            if (result.success) {
                updateField('picture', result.url);
                toast.success('Image uploaded successfully');
            } else {
                toast.error(result.message || 'Failed to upload image');
                updateField('picture', '');
            }
        } catch (error) {
            console.error('Upload error:', error);
            toast.error('Failed to upload image. Please try again.');
            updateField('picture', '');
        } finally {
            setUploadingImage(false);
        }
    };

    const validateAndSave = async () => {
        if (!deal) return;

        const newErrors: DealErrors = {};
        let hasError = false;

        if (!deal.picture) {
            newErrors.picture = 'Picture is required';
            hasError = true;
        }

        if (!deal.dealType) {
            newErrors.dealType = 'Deal Type is required';
            hasError = true;
        }

        if (!deal.store) {
            newErrors.store = 'Deal Store is required';
            hasError = true;
        }

        if (!deal.coupon && !deal.clearance && !deal.disableExpireAt) {
            if (!deal.expiredDate) {
                newErrors.expiredDate = 'Expiry Date is required';
                hasError = true;
            } else {
                const selectedDate = new Date(deal.expiredDate);
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                if (selectedDate < today) {
                    newErrors.expiredDate = 'Expiry Date must be in the future';
                    hasError = true;
                }
            }
        } else {
            newErrors.expiredDate = undefined;
        }

        if (!deal.shortDescription?.trim()) {
            newErrors.shortDescription = 'Deal Short Description is required';
            hasError = true;
        }

        if (!deal.originalPrice || deal.originalPrice <= 0) {
            newErrors.originalPrice = 'Original Price is required and must be greater than 0';
            hasError = true;
        }

        if (deal.discountPrice < 0) {
            newErrors.discountPrice = 'Discount Price cannot be negative';
            hasError = true;
        }

        if (deal.discountPrice >= deal.originalPrice && deal.originalPrice > 0) {
            newErrors.discountPrice = 'Discount Price must be less than Original Price';
            hasError = true;
        }

        if (!deal.purchaseLink?.trim()) {
            newErrors.purchaseLink = 'Purchase Link is required';
            hasError = true;
        } else {
            try {
                const urlToValidate = deal.purchaseLink.match(/^https?:\/\//)
                    ? deal.purchaseLink
                    : `https://${deal.purchaseLink}`;

                new URL(urlToValidate);

                deal.purchaseLink = urlToValidate;

                if (errors?.purchaseLink === 'Purchase link already exists') {
                    newErrors.purchaseLink = 'Purchase link already exists';
                    hasError = true;
                }

                if (checkingDuplicate?.purchaseLink) {
                    newErrors.purchaseLink = 'Checking purchase link, please wait...';
                    hasError = true;
                }
            } catch {
                newErrors.purchaseLink = 'Invalid URL format';
                hasError = true;
            }
        }

        if (!deal.description.trim() || stripHtmlTags(deal.description).trim().length === 0) {
            newErrors.description = 'Description is required';
            hasError = true;
        }

        setErrors(newErrors);

        if (hasError) {
            toast.error('Please fix all validation errors');
            return;
        }

        setLoader(true);

        try {
            const { id, ...restDeal } = deal;
            const dealToUpdate = {
                _id: id,
                ...restDeal,
            };

            const res = await updateDeal(id.toString(), dealToUpdate);

            if (res.success) {
                toast.success(res?.message || 'Deal updated successfully');
                Router.push('/dashboard');
            } else {
                toast.error(res?.message || 'Failed to update deal');
            }
        } catch (error) {
            console.error('Update error:', error);
            toast.error('An error occurred while updating the deal');
        } finally {
            setLoader(false);
        }
    };

    // Picture Upload Component with Clipboard Support
    const PictureUploadSection = () => {
        const fileInputRef = useRef<HTMLInputElement | null>(null);
        const containerRef = useRef<HTMLDivElement | null>(null);

        const handleContainerClick = () => {
            if (!uploadingImage) {
                fileInputRef.current?.click();
            }
        };

        const handleFocus = () => {
            setIsPasteFocused(true);
        };

        const handleBlur = () => {
            setTimeout(() => {
                setIsPasteFocused(false);
            }, 7000);
        };

        return (
            <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Deal Picture *</label>
                <div className="flex flex-col items-center gap-3">
                    {uploadingImage && (
                        <div className="text-sm text-blue-600 font-medium animate-pulse">Uploading image...</div>
                    )}

                    {deal?.picture && (
                        <div className="relative group w-fit">
                            <img
                                src={deal.picture}
                                alt="Deal"
                                className="w-40 h-40 object-cover rounded-lg border-2 border-gray-300 shadow-sm"
                            />
                            <button
                                onClick={handleContainerClick}
                                type="button"
                                className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg"
                                title="Change image"
                            >
                                <Upload size={24} className="text-white" />
                            </button>
                        </div>
                    )}

                    {/* Paste Area - Focusable */}
                    <div
                        ref={containerRef}
                        tabIndex={0}
                        onFocus={handleFocus}
                        onBlur={handleBlur}
                        onClick={handleContainerClick}
                        className={`max-w-md border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-all outline-none ${
                            uploadingImage
                                ? 'border-gray-300 bg-gray-50 cursor-not-allowed opacity-50'
                                : isPasteFocused
                                  ? 'border-blue-500 bg-blue-100 ring-2 ring-blue-300'
                                  : 'border-blue-300 bg-blue-50 hover:bg-blue-100 hover:border-blue-400'
                        }`}
                        title="Click to upload or focus and press Ctrl+V to paste"
                    >
                        <div className="flex flex-col items-center gap-2">
                            <Clipboard size={28} className="text-blue-600" />
                            <div className="text-sm text-gray-700">
                                <span className="font-semibold">
                                    {isPasteFocused ? 'Press Ctrl+V to paste' : 'Click to upload'}
                                </span>
                                <span className="block text-xs text-gray-500 mt-1">
                                    or focus and paste from clipboard
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Hidden File Input */}
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/jpg,image/png,image/webp,image/gif"
                        onChange={handleImageUpload}
                        disabled={uploadingImage}
                        className="hidden"
                    />

                    {errors.picture && <span className="text-sm text-red-500 font-medium">{errors.picture}</span>}
                </div>
            </div>
        );
    };

    if (isLoading) {
        return <Loading />;
    }

    if (!deal) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <p className="text-xl text-gray-600">Deal not found</p>
                    <button onClick={() => Router.push('/dashboard')} className="mt-4 text-blue-600 hover:underline">
                        Go back to dashboard
                    </button>
                </div>
            </div>
        );
    }

    const isDisableExpireAt = deal.disableExpireAt || deal.coupon || deal.clearance;

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center gap-3">
                        <button
                            onClick={() => Router.push('/dashboard')}
                            className="text-gray-600 hover:text-gray-800 transition-colors"
                        >
                            <ArrowLeft size={24} />
                        </button>
                        <h1 className="text-3xl font-bold text-gray-800">Update Deal</h1>
                    </div>
                    <button
                        onClick={validateAndSave}
                        disabled={loader || uploadingImage}
                        className="bg-green-600 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Save size={20} />
                        {loader ? 'Saving...' : 'Save Changes'}
                    </button>
                </div>

                {/* Instructions */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                    <p className="text-sm text-blue-800">
                        💡 <strong>Tip:</strong> Click on the paste area to focus it, then press{' '}
                        <kbd className="px-2 py-1 bg-white border border-blue-300 rounded text-xs">Ctrl+V</kbd> to paste
                        an image from your clipboard!
                    </p>
                </div>

                {loader ? (
                    <div className="w-full flex-col h-96 flex items-center justify-center">
                        <TailSpin
                            height="50"
                            width="50"
                            color="orange"
                            ariaLabel="tail-spin-loading"
                            radius="1"
                            visible={true}
                        />
                        <p className="text-sm mt-2 font-semibold text-orange-500">Updating Deal...</p>
                    </div>
                ) : (
                    <div className="bg-white rounded-lg shadow-md p-6">
                        <div className="space-y-6">
                            {/* Picture Upload with Clipboard Support */}
                            <PictureUploadSection />

                            {/* Deal Type */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Deal Type *</label>

                                <Select
                                    isMulti
                                    menuPortalTarget={typeof window !== 'undefined' ? document.body : null}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                    isLoading={loadingMeta}
                                    isDisabled={loadingMeta}
                                    classNamePrefix="react-select"
                                    placeholder="Select deal type"
                                    options={dealTypes.map((type) => ({
                                        value: type._id,
                                        label: type.name,
                                    }))}
                                    value={dealTypes
                                        .filter((type) => deal.dealType?.includes(type._id))
                                        .map((type) => ({
                                            value: type._id,
                                            label: type.name,
                                        }))}
                                    onChange={(selectedOptions) =>
                                        updateField(
                                            'dealType',
                                            selectedOptions.map((opt) => opt.value),
                                        )
                                    }
                                    className={errors.dealType ? 'border-red-500' : ''}
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderColor: errors.dealType
                                                ? '#ef4444'
                                                : state.isFocused
                                                  ? '#3b82f6'
                                                  : '#d1d5db',
                                            boxShadow: 'none',
                                            '&:hover': {
                                                borderColor: '#3b82f6',
                                            },
                                            minHeight: '48px',
                                        }),
                                    }}
                                />

                                {errors.dealType && (
                                    <span className="text-sm text-red-500 mt-1 block">{errors.dealType}</span>
                                )}
                            </div>

                            {/* Deal Store */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Deal Store *</label>
                                <Select
                                    menuPortalTarget={typeof window !== 'undefined' ? document.body : null}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                    isClearable
                                    classNamePrefix="react-select"
                                    placeholder="Select Deal Store"
                                    options={stores.map((store) => ({
                                        value: store._id,
                                        label: store.name,
                                    }))}
                                    value={
                                        deal.store
                                            ? {
                                                  value: deal.store,
                                                  label: stores.find((s) => s._id === deal.store)?.name || deal.store,
                                              }
                                            : null
                                    }
                                    onChange={(selected) => updateField('store', selected ? selected.value : '')}
                                    className={errors.store ? 'border-red-500' : ''}
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderColor: errors.store
                                                ? '#ef4444'
                                                : state.isFocused
                                                  ? '#3b82f6'
                                                  : '#d1d5db',
                                            boxShadow: 'none',
                                            minHeight: '48px',
                                            '&:hover': {
                                                borderColor: '#3b82f6',
                                            },
                                        }),
                                    }}
                                />
                                {errors.store && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.store}</span>
                                )}
                            </div>

                            {/* Expiry Date */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Expiry Date *</label>
                                <div className="flex items-center gap-1">
                                    <input
                                        type="date"
                                        value={toDateInputValue(deal.expiredDate)}
                                        onChange={(e) => updateField('expiredDate', e.target.value)}
                                        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                                            errors.expiredDate ? 'border-red-500' : 'border-gray-300'
                                        }`}
                                        disabled={isDisableExpireAt}
                                    />
                                    <input
                                        type="checkbox"
                                        checked={deal.disableExpireAt}
                                        onChange={(e) => updateField('disableExpireAt', e.target.checked)}
                                        disabled={deal.coupon || deal.clearance}
                                        className="w-5 h-5 accent-green-600"
                                    />
                                </div>
                                {errors.expiredDate && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.expiredDate}</span>
                                )}
                            </div>

                            {/* Deal Short Description */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Deal Short Description *
                                </label>
                                <div className="relative">
                                    <input
                                        type="text"
                                        value={deal.shortDescription || ''}
                                        onChange={(e) => {
                                            const value = e.target.value;

                                            updateField('shortDescription', value);

                                            debounceCheckDuplicate(
                                                String(deal.id),
                                                { shortDescription: value },
                                                setErrors,
                                                setCheckingDuplicate,
                                            );
                                        }}
                                        placeholder="Enter deal short description"
                                        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                                            errors.shortDescription ? 'border-red-500' : 'border-gray-300'
                                        }`}
                                    />

                                    {/* Loading icon */}
                                    {checkingDuplicate?.shortDescription && (
                                        <span className="absolute inset-y-0 right-2 flex items-center">
                                            <svg
                                                className="animate-spin h-4 w-4 text-gray-500"
                                                viewBox="0 0 24 24"
                                                fill="none"
                                            >
                                                <circle
                                                    className="opacity-25"
                                                    cx="12"
                                                    cy="12"
                                                    r="10"
                                                    stroke="currentColor"
                                                    strokeWidth="4"
                                                />
                                                <path
                                                    className="opacity-75"
                                                    fill="currentColor"
                                                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                                                />
                                            </svg>
                                        </span>
                                    )}
                                </div>

                                {errors.shortDescription && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.shortDescription}</span>
                                )}
                            </div>

                            {/* Original Price */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Original Price *
                                </label>
                                <input
                                    type="number"
                                    value={deal.originalPrice || ''}
                                    onChange={(e) => updateField('originalPrice', Number(e.target.value))}
                                    placeholder="299"
                                    min="0"
                                    step="0.01"
                                    className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                                        errors.originalPrice ? 'border-red-500' : 'border-gray-300'
                                    }`}
                                />
                                {errors.originalPrice && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.originalPrice}</span>
                                )}
                            </div>

                            {/* Discount Price */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Discount Price *
                                </label>
                                <input
                                    type="number"
                                    value={deal.discountPrice || ''}
                                    onChange={(e) => updateField('discountPrice', Number(e.target.value))}
                                    placeholder="269"
                                    min="0"
                                    step="0.01"
                                    className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                                        errors.discountPrice ? 'border-red-500' : 'border-gray-300'
                                    }`}
                                />
                                {errors.discountPrice && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.discountPrice}</span>
                                )}
                            </div>

                            {/* Percentage Off */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Percentage Off</label>
                                <input
                                    type="text"
                                    value={deal.percentageOff || ''}
                                    readOnly
                                    placeholder="Auto-calculated"
                                    className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                                />
                            </div>

                            {/* Purchase Link */}
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Purchase Link *
                                </label>
                                <div className="relative">
                                    <input
                                        type="text"
                                        value={deal.purchaseLink || ''}
                                        onChange={(e) => {
                                            const value = e.target.value;

                                            updateField('purchaseLink', value);

                                            debounceCheckDuplicate(
                                                String(deal.id),
                                                { purchaseLink: value },
                                                setErrors,
                                                setCheckingDuplicate,
                                            );
                                        }}
                                        placeholder="https://example.com/deal"
                                        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                                            errors.purchaseLink ? 'border-red-500' : 'border-gray-300'
                                        }`}
                                    />
                                    {/* Loading icon */}
                                    {checkingDuplicate?.purchaseLink && (
                                        <span className="absolute inset-y-0 right-2 flex items-center">
                                            <svg
                                                className="animate-spin h-4 w-4 text-gray-500"
                                                viewBox="0 0 24 24"
                                                fill="none"
                                            >
                                                <circle
                                                    className="opacity-25"
                                                    cx="12"
                                                    cy="12"
                                                    r="10"
                                                    stroke="currentColor"
                                                    strokeWidth="4"
                                                />
                                                <path
                                                    className="opacity-75"
                                                    fill="currentColor"
                                                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                                                />
                                            </svg>
                                        </span>
                                    )}
                                </div>
                                {errors.purchaseLink && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.purchaseLink}</span>
                                )}
                            </div>

                            {/* Deal Flags */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="border rounded-lg p-4 bg-gray-50">
                                    <ToggleSwitch
                                        label="Hot Trend"
                                        checked={!!deal.hotTrend}
                                        onChange={(val) => updateField('hotTrend', val)}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">Mark this deal as trending / popular</p>
                                </div>

                                <div className="border rounded-lg p-4 bg-gray-50">
                                    <ToggleSwitch
                                        label="Holiday Deals"
                                        checked={!!deal.holidayDeals}
                                        onChange={(val) => updateField('holidayDeals', val)}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">Show this deal in holiday campaigns</p>
                                </div>

                                <div className="border rounded-lg p-4 bg-gray-50">
                                    <ToggleSwitch
                                        label="Seasonal Deals"
                                        checked={!!deal.seasonalDeals}
                                        onChange={(val) => updateField('seasonalDeals', val)}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">Show this deal in seasonal campaigns</p>
                                </div>

                                {/* Coupon */}
                                <div className="border rounded-lg p-4 bg-gray-50">
                                    <ToggleSwitch
                                        label="Coupon"
                                        checked={!!deal.coupon}
                                        onChange={(val) => updateField('coupon', val)}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">Mark this deal as having a coupon</p>
                                </div>

                                {/* Clearance */}
                                <div className="border rounded-lg p-4 bg-gray-50">
                                    <ToggleSwitch
                                        label="Clearance"
                                        checked={!!deal.clearance}
                                        onChange={(val) => updateField('clearance', val)}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">
                                        Mark this deal as clearance / clearance sale
                                    </p>
                                </div>
                            </div>

                            {/* Description */}
                            <div className="!mb-6">
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Description *</label>
                                <div className="quill-wrapper">
                                    <ReactQuill
                                        style={{ height: '350px' }}
                                        theme="snow"
                                        value={deal.description || ''}
                                        onChange={(value) => updateField('description', value)}
                                        placeholder="Enter deal description..."
                                        className="quill-editor"
                                        modules={{
                                            toolbar: [
                                                [{ header: [1, 2, 3, false] }],
                                                ['bold', 'italic', 'underline', 'strike'],
                                                [{ list: 'ordered' }, { list: 'bullet' }],
                                                [{ color: [] }, { background: [] }],
                                                ['link'],
                                                ['clean'],
                                            ],
                                        }}
                                    />
                                </div>
                                {errors.description && (
                                    <span className="text-sm text-red-500 block mt-1">{errors.description}</span>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
