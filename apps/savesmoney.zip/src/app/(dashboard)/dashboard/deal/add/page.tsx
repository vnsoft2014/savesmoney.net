import { AddDeal } from '@/components/dashboard/add-deal';

export const metadata = {
    title: 'Add Deal | Admin Dashboard',
};

export default function AddDealPage() {
    return <AddDeal />;
}
