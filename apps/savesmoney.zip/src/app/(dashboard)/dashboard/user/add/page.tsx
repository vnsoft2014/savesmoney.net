'use client';

import AddUserForm from '@/components/dashboard/user/AddUserForm';

export default function Page() {
    return <AddUserForm />;
}
