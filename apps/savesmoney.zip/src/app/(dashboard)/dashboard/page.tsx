import { Metadata } from 'next';
import AdminNavbar from '@/components/dashboard/AdminNavbar';
import AdminSidebar from '@/components/dashboard/AdminSidebar';
import SuperComponent from '@/components/dashboard/SuperComponent';
import { SITE } from '@/utils/site';

export const metadata: Metadata = {
    title: `Dashboard | ${SITE.name}`,
};

const Page = () => {
    return (
        <div className="w-full h-screen flex bg-gray-50 overflow-hidden">
            <AdminSidebar />
            <div className="w-full h-full">
                <AdminNavbar />
                <div className="w-full h-5/6 flex flex-wrap items-start justify-center overflow-y-auto px-4 py-2">
                    <SuperComponent />
                </div>
            </div>
        </div>
    );
};

export default Page;
