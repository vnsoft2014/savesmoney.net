'use client';

import AddDealTypeForm from '@/components/dashboard/deal-type/AddDealTypeForm';

export default function Page() {
    return <AddDealTypeForm />;
}
